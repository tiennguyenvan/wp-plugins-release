<?php
/**
 * DragBlock's Applications.
 *
 * @package Shortcodes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'shortcodes.php';
