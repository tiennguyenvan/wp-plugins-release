<?php
/**
 * DragBlock's Applications.
 *
 * @package Editor panel attributes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'attributes-enqueue.php';
require_once 'attributes-uid.php';
require_once 'attributes-render.php';
