<?php
/**
 * DragBlock's Src.
 *
 * @package Library
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'lib-common.php';
require_once 'lib-enqueue.php';
