<?php
/**
 * DragBlock's Applications.
 *
 * @package Editor panel database
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'database-enqueue.php';
require_once 'database-render.php';
