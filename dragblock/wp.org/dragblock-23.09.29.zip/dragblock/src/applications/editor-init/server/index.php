<?php
/**
 * DragBlock's Applications.
 *
 * @package Editor init
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'editor-init-enqueue.php';
