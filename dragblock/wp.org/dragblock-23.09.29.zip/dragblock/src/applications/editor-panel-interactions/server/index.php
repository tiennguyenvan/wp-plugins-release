<?php
/**
 * DragBlock's Applications.
 *
 * @package Editor panel interactions
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'interactions-enqueue.php';
