<?php
/**
 * DragBlock's Applications.
 *
 * @package Theme settings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'default-theme-json.php';
