<?php
/**
 * DragBlock's Applications.
 *
 * @package Form entries
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'form-defines.php';
require_once 'form-admin-page.php';
require_once 'form-custom-post-type.php';
require_once 'form-enqueues.php';
require_once 'form-render.php';
require_once 'form-submission.php';
