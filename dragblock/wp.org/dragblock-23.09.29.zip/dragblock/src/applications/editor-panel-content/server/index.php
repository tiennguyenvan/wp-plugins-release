<?php
/**
 * DragBlock's Applications.
 *
 * @package Editor panel content
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'content-enqueue.php';
require_once 'content-render.php';
