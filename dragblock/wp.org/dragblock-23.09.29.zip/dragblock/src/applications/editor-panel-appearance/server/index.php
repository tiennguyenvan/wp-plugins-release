<?php
/**
 * DragBlock's Applications.
 *
 * @package Editor panel appearance
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'appearance-enqueue.php';
