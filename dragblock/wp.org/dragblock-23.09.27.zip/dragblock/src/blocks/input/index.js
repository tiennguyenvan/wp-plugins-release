/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/applications/editor-panel-attributes/client/attributes-settings.js":
/*!********************************************************************************!*\
  !*** ./src/applications/editor-panel-attributes/client/attributes-settings.js ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   attributesNames: function() { return /* binding */ attributesNames; },
/* harmony export */   deleteAttr: function() { return /* binding */ deleteAttr; },
/* harmony export */   findAttrIndex: function() { return /* binding */ findAttrIndex; },
/* harmony export */   getAttr: function() { return /* binding */ getAttr; },
/* harmony export */   initDragBlockAttrs: function() { return /* binding */ initDragBlockAttrs; },
/* harmony export */   setAttr: function() { return /* binding */ setAttr; }
/* harmony export */ });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);


const initDragBlockAttrs = propname => {
  let dragBlockAttrs = new Array();
  // dragBlockAttrs.push(cloneDeep({ slug: 'display', value: '' }))

  if ('dragblock/image' === propname) {
    dragBlockAttrs.push((0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)({
      slug: 'src',
      value: '[dragblock.post.image.src]'
    }));
    // dragBlockAttrs.push(cloneDeep({ slug: 'alt', value: '[dragblock.post.title]' }))
    // dragBlockAttrs.push(cloneDeep({ slug: 'loading', value: 'lazy' }))
    // dragBlockAttrs.push(cloneDeep({ slug: 'decoding', value: 'async' }))
  }

  return (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(dragBlockAttrs);
};
const attributesNames = {
  /**
   * LINK
   */
  'href': {
    keyword: 'href link url',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Href', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('URL of the link', 'dragblock'),
    type: 'text'
  },
  'target': {
    keyword: 'target',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Target', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Target window, tab, or element to open the link', 'dragblock'),
    type: 'select',
    options: [{
      value: '',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Default', 'dragblock')
    }, {
      value: '_blank',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Blank', 'dragblock')
    }, {
      value: '_parent',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Parent', 'dragblock')
    }, {
      value: '_self',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Self', 'dragblock')
    }, {
      value: '_top',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Top', 'dragblock')
    }]
  },
  'rel': {
    keyword: 'rel',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Rel', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Relationship between the linked resource and the current document', 'dragblock'),
    type: 'text'
  },
  'tabindex': {
    keyword: 'tabindex',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Tab Index', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Order in focus navigating sequence', 'dragblock'),
    type: 'number'
  },
  /**
   * IMAGES
   */
  'src': {
    keyword: 'src',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Src', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('URL of the media', 'dragblock'),
    type: 'text'
  },
  'alt': {
    keyword: 'alt',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Alt', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Alternative text', 'dragblock'),
    type: 'multilingual-text'
  },
  /**
   * FORM
   */

  'name': {
    keyword: 'name',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Name', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Name', 'dragblock'),
    type: 'text'
  },
  'placeholder': {
    keyword: 'placeholder',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Placeholder', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Placeholder', 'dragblock'),
    type: 'multilingual-text'
  },
  'title': {
    keyword: 'title',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Title', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('title', 'dragblock'),
    type: 'multilingual-text'
  },
  'type': {
    keyword: 'type',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Type', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('type', 'dragblock'),
    type: 'select',
    options: [{
      value: 'text',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Text', 'dragblock')
    }, {
      value: 'submit',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Submit', 'dragblock')
    }, {
      value: 'password',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Password', 'dragblock')
    }, {
      value: 'checkbox',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Checkbox', 'dragblock')
    }, {
      value: 'radio',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Radio', 'dragblock')
    }, {
      value: 'button',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Button', 'dragblock')
    }, {
      value: 'number',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Number', 'dragblock')
    }, {
      value: 'email',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Email', 'dragblock')
    }, {
      value: 'tel',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Phone', 'dragblock')
    }, {
      value: 'url',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('URL', 'dragblock')
    }, {
      value: 'date',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Date', 'dragblock')
    }, {
      value: 'time',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Time', 'dragblock')
    }, {
      value: 'month',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Month', 'dragblock')
    }, {
      value: 'week',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Week', 'dragblock')
    }, {
      value: 'range',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Range', 'dragblock')
    }, {
      value: 'color',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Color', 'dragblock')
    }, {
      value: 'search',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Search', 'dragblock')
    }, {
      value: 'file',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('File', 'dragblock')
    }, {
      value: 'hidden',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Hidden', 'dragblock')
    }, {
      value: 'reset',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Reset', 'dragblock')
    }]
  },
  'value': {
    keyword: 'value',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Value', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('value', 'dragblock'),
    type: 'multilingual-text'
  },
  'disabled': {
    keyword: 'disabled',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Disabled', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Not mutable, focusable, submitted', 'dragblock'),
    type: 'text'
  },
  'required': {
    keyword: 'required',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Required', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('required', 'dragblock'),
    type: 'text'
  },
  'selected': {
    keyword: 'selected',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Selected', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('selected', 'dragblock'),
    type: 'text'
  },
  'action': {
    keyword: 'action',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Action', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('action', 'dragblock'),
    type: 'action'
  },
  'method': {
    keyword: 'method',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Method', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('method', 'dragblock'),
    type: 'select',
    options: [{
      value: 'POST',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('POST', 'dragblock')
    }, {
      value: 'GET',
      label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('GET', 'dragblock')
    }
    // {value: 'CONNECT', label: __('CONNECT', 'dragblock')},
    // {value: 'DELETE', label: __('DELETE', 'dragblock')},
    // {value: 'HEAD', label: __('HEAD', 'dragblock')},
    // {value: 'OPTIONS', label: __('OPTIONS', 'dragblock')},
    // {value: 'PATCH', label: __('PATCH', 'dragblock')},
    // {value: 'PUT', label: __('PUT', 'dragblock')},
    // {value: 'TRACE', label: __('TRACE', 'dragblock')},
    ]
  },

  'for': {
    keyword: 'for',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('For', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('For a block with certain ID', 'dragblock'),
    type: 'text'
  },
  'sizes': {
    keyword: 'sizes',
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Sizes', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Image sizes in different screen', 'dragblock'),
    type: 'unit'
  }
  // 'decoding': {
  // 	keyword: 'decoding decode load image',
  // 	label: __('Decoding', 'dragblock'),
  // 	note: __('Decode asynchronously or synchronously', 'dragblock'),
  // 	type: 'select',
  // 	options: [
  // 		{ value: '', label: __('Default', 'dragblock') },
  // 		{ value: 'async', label: __('Async', 'dragblock') },
  // 		{ value: 'sync', label: __('Sync', 'dragblock') },
  // 	]
  // },
  // 'loading': {
  // 	keyword: 'loading load onload image',
  // 	label: __('Loading', 'dragblock'),
  // 	note: __('Loading immediately or wait viewport', 'dragblock'),
  // 	type: 'select',
  // 	options: [
  // 		{ value: '', label: __('Default', 'dragblock') },
  // 		{ value: 'lazy', label: __('Lazy', 'dragblock') },
  // 		{ value: 'eager', label: __('Eager', 'dragblock') },
  // 	]
  // },
};

/**
 * 
 * @param {*} attrList : {index: attr : {slug, value, disabled}}
 * @param {*} slug 
 * @returns 
 */
const findAttrIndex = (attrList, slug) => {
  if (attrList) {
    for (let [index, attr] of attrList.entries()) {
      if (attr['slug'] === slug && !attr['disabled']) return index;
    }
  }
  return -1;
};
const getAttr = (attrList, slug) => {
  let index = findAttrIndex(attrList, slug);
  if (index === -1) return null;
  return attrList[index]['value'];
};
const deleteAttr = (attrList, slug) => {
  let index = findAttrIndex(attrList, slug);
  if (index > -1) {
    attrList.splice(index, 1);
  }
};
const setAttr = (attrList, slug, value) => {
  let index = findAttrIndex(attrList, slug);
  if (index === -1) {
    attrList.unshift({
      'slug': slug,
      'value': value
    });
    return attrList;
  }
  attrList[index]['value'] = value;
  return attrList;
};

/**
 * @info register custom HTML attributes and supports features
 */
wp.hooks.addFilter('blocks.registerBlockType', 'dragblock/attributes-register', function (settings, name) {
  // for all blocks
  settings = Object.assign({}, settings, {
    // override the attributes in the block.json files
    attributes: Object.assign({}, settings.attributes, {
      // use to apply custom css
      // we have to use in-object attribute here to have data for front-end to modify the implied blocks (like nav-link)
      // dragBlockClientId: {
      // 	type: 'string',
      // 	source: 'attribute',
      // 	attribute: 'data-dragblock-client-id',
      // 	default: '',
      // 	selector: '*',
      // },
      dragBlockClientId: {
        type: 'string'
      },
      // classname and id (anchor) are supported from the Advanced tab
      // ****************************************************************				
      anchor: {
        type: 'string',
        source: 'attribute',
        default: '',
        attribute: 'id',
        selector: '*' // very important
      },

      className: {
        type: 'string',
        default: ''
      },
      // we use this all-in-one method so we don't have to have a long code
      // in save / edit function. Also easy to add more properties for the tag attributes
      // in the future
      // ****************************************************************
      // just in case we could have conditions for attributes so we can add many attributes
      // that have the same name but different properties. This is the reason why we have
      // to define the dragBlockAttrs as an array
      /**
      dragBlockAttrs: [
      	{
      		slug : 'tabindex',
      		value: '',
      		disabled: '' // f = disabled on front-end, b = disabled on back-end, * = disabled on all
      	}
      ]				
       */
      dragBlockAttrs: {
        type: 'array',
        default: ''
      }
    })
  });

  // for DragBlock blocks		
  if (name.indexOf('dragblock') !== -1) {
    settings = Object.assign({}, settings, {
      // override the attributes in the block.json files
      attributes: Object.assign({}, settings.attributes, {
        // anchor: {
        // 	type: 'string',
        // 	source: 'attribute',
        // 	default: '',
        // 	attribute: 'id',
        // 	selector: '*', // very important
        // },
      }),
      // override the supports in the block.js files
      supports: Object.assign({}, settings.supports, {
        // allow input an ID for blocks in the Advanced panel
        anchor: true
      })
    });
  }

  // for certain blocks
  // if ((name === 'dragblock/link')) {
  // 	settings = Object.assign({}, settings, {
  // 		// override the attributes in the block.json files
  // 		attributes: Object.assign({}, settings.attributes, {
  // 			dragBlockAttrHref: {
  // 				type: 'string', 
  // 				source: 'attribute',
  // 				attribute: 'href',
  // 				default: '',
  // 				selector: '*', 
  // 			},
  // 			dragBlockAttrTarget: {
  // 				type: 'string', 
  // 				source: 'attribute',
  // 				attribute: 'target',
  // 				default: '',
  // 				selector: '*', 
  // 			},
  // 			dragBlockAttrRel: {
  // 				type: 'string', 
  // 				source: 'attribute',
  // 				attribute: 'rel',
  // 				default: '',
  // 				selector: '*', 
  // 			},
  // 		}),
  // 	});
  // }

  return settings;
});

/***/ }),

/***/ "./src/blocks/input/edit.js":
/*!**********************************!*\
  !*** ./src/blocks/input/edit.js ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Edit; }
/* harmony export */ });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/hooks */ "@wordpress/hooks");
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _editor_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./editor.scss */ "./src/blocks/input/editor.scss");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _applications_editor_panel_attributes_client_attributes_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../applications/editor-panel-attributes/client/attributes-settings */ "./src/applications/editor-panel-attributes/client/attributes-settings.js");
/* harmony import */ var _library_client_ultils_shortcodes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../library/client/ultils/shortcodes */ "./src/library/client/ultils/shortcodes.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_8__);










/**
 * 
 * @param {Object} props 
 * @returns 
 */
function Edit(props) {
  const {
    attributes,
    setAttributes,
    isSelected,
    clientId
  } = props;
  let {
    dragBlockAttrs,
    dragBlockClientId
  } = attributes;
  // default attributes for input
  if (!dragBlockAttrs) {
    const newAttr = [{
      slug: 'name',
      value: dragBlockClientId ? dragBlockClientId : clientId
    }, {
      slug: 'type',
      value: 'text'
    }, {
      slug: 'placeholder',
      value: 'Input a text',
      locale: 'en_US'
    }];
    setAttributes({
      dragBlockAttrs: (0,lodash__WEBPACK_IMPORTED_MODULE_8__.cloneDeep)(newAttr)
    });
    dragBlockAttrs = newAttr;
  }
  let blockProps = (0,_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_2__.useBlockProps)();
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    ...blockProps,
    onChange: () => {}
  });
}

/***/ }),

/***/ "./src/blocks/input/save.js":
/*!**********************************!*\
  !*** ./src/blocks/input/save.js ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ save; }
/* harmony export */ });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/hooks */ "@wordpress/hooks");
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_2__);




/**
 * 
 * @param {Object} props 
 * @returns 
 */
function save(props) {
  const {
    attributes
  } = props;
  let blockProps = _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_1__.useBlockProps.save();
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    ...blockProps
  });
}

/***/ }),

/***/ "./src/library/client/ultils/shortcodes.js":
/*!*************************************************!*\
  !*** ./src/library/client/ultils/shortcodes.js ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dragBlockQueryShortcodes: function() { return /* binding */ dragBlockQueryShortcodes; }
/* harmony export */ });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);

const dragBlockQueryShortcodes = {
  // form shortcodes
  '[dragblock.form.message.error]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Form Submission Error Message', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Error message after submitting form', 'dragblock'),
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('DragBlock Form Error: There is an uknown server error.', 'dragblock')
  },
  // current post shortcode
  '[dragblock.post.title]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Title', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('The parsed post\'s Title', 'dragblock'),
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('The DragBlock Post Title', 'dragblock')
  },
  '[dragblock.post.url]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post URL', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('The parsed post\'s url', 'dragblock')
  },
  '[dragblock.post.image.src]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Image Thumbnail SRC', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('the parsed post\'s image src', 'dragblock')
  },
  // '[dragblock.post.image.src size="thumbnail"]': {
  //     label: __('Post Small Thumbnail SRC', 'dragblock'),
  //     note: __('the parsed post\'s image src (small Size)', 'dragblock'),

  // },
  // '[dragblock.post.image.src size="medium"]': {
  //     label: __('Post Medium Thumbnail SRC', 'dragblock'),
  //     note: __('the parsed post\'s image src (medium size)', 'dragblock'),

  // },
  // '[dragblock.post.image.src size="large"]': {
  //     label: __('Post Large Thumbnail SRC', 'dragblock'),
  //     note: __('the parsed post\'s image src (large size)', 'dragblock'),

  // },
  '[dragblock.post.author.url]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Author URL', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('the parsed post\'s author page url', 'dragblock')
  },
  '[dragblock.post.author.name]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Author Name', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('The parsed post\'s author name', 'dragblock'),
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Author Name', 'dragblock')
  },
  '[dragblock.post.author.avatar.src]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Author Avatar SRC', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('The parsed post\'s author\'s avatar SRC', 'dragblock')
  },
  // allow to input format attributes, ex: format="friendly"
  '[dragblock.post.date]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Date Name', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('The parsed post\'s date', 'dragblock'),
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('July 01, 2086', 'dragblock')
  },
  '[dragblock.post.comment.count]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Comment Count', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('The parsed post\'s comment number', 'dragblock'),
    placeholder: '0'
  },
  '[dragblock.post.snippet]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Snippet', 'dragblock'),
    note: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('The parsed post\'s snippet', 'dragblock'),
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Get the first paragraph of the post content. If the post excerpt, a custom summary of the post that author manually inputted when composing the post content, exists, use that instead', 'dragblock')
  },
  // allow to input index attributes to get the right category/tag
  '[dragblock.post.cat.name]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Category Name', 'dragblock'),
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Category Name', 'dragblock')
    // note: __('index="first/last/root/leaf/most/least"', 'dragblock')
  },

  '[dragblock.post.cat.url]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Category URL', 'dragblock')
    // note: __('index="first/last/root/leaf/most/least"', 'dragblock')
  },

  '[dragblock.post.tag.name]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Tag Name', 'dragblock'),
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Tag Name', 'dragblock')
    // note: __('index="first/last/root/leaf/most/least"', 'dragblock')
  },

  '[dragblock.post.tag.url]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Post Tag URL', 'dragblock')
    // note: __('index="first/last/root/leaf/most/least"', 'dragblock')
  },

  // sharing shortcode
  '[dragblock.share.url.twitter]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Twitter Share URL', 'dragblock')
    // placeholder: __('', 'dragblock'),
    // note: __('', 'dragblock')
  },

  '[dragblock.share.url.facebook]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Facebook Share URL', 'dragblock')
    // placeholder: __('', 'dragblock'),
    // note: __('', 'dragblock')
  },

  '[dragblock.share.url.whatsapp]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Whatsapp Share URL', 'dragblock')
    // placeholder: __('', 'dragblock'),
    // note: __('', 'dragblock')
  },

  '[dragblock.share.url.telegram]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Telegram Share URL', 'dragblock')
    // placeholder: __('', 'dragblock'),
    // note: __('', 'dragblock')
  },

  '[dragblock.share.url.tumblr]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Tumblr Share URL', 'dragblock')
    // placeholder: __('', 'dragblock'),
    // note: __('', 'dragblock')
  },

  '[dragblock.share.url.reddit]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Reddit Share URL', 'dragblock')
    // placeholder: __('', 'dragblock'),
    // note: __('', 'dragblock')
  },

  '[dragblock.share.url.linkedin]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('LinkedIn Share URL', 'dragblock')
    // placeholder: __('', 'dragblock'),
    // note: __('', 'dragblock')
  },

  '[dragblock.share.url.gmail]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Gmail Share URL', 'dragblock')
    // placeholder: __('', 'dragblock'),
    // note: __('', 'dragblock')
  },

  '[dragblock.share.url.navigator]': {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Navigator Share URL', 'dragblock')
    // placeholder: __('', 'dragblock'),
    // note: __('', 'dragblock')
  }
};

/***/ }),

/***/ "./src/blocks/input/editor.scss":
/*!**************************************!*\
  !*** ./src/blocks/input/editor.scss ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/***/ (function(module) {

module.exports = window["lodash"];

/***/ }),

/***/ "@wordpress/block-editor":
/*!*************************************!*\
  !*** external ["wp","blockEditor"] ***!
  \*************************************/
/***/ (function(module) {

module.exports = window["wp"]["blockEditor"];

/***/ }),

/***/ "@wordpress/blocks":
/*!********************************!*\
  !*** external ["wp","blocks"] ***!
  \********************************/
/***/ (function(module) {

module.exports = window["wp"]["blocks"];

/***/ }),

/***/ "@wordpress/components":
/*!************************************!*\
  !*** external ["wp","components"] ***!
  \************************************/
/***/ (function(module) {

module.exports = window["wp"]["components"];

/***/ }),

/***/ "@wordpress/element":
/*!*********************************!*\
  !*** external ["wp","element"] ***!
  \*********************************/
/***/ (function(module) {

module.exports = window["wp"]["element"];

/***/ }),

/***/ "@wordpress/hooks":
/*!*******************************!*\
  !*** external ["wp","hooks"] ***!
  \*******************************/
/***/ (function(module) {

module.exports = window["wp"]["hooks"];

/***/ }),

/***/ "@wordpress/i18n":
/*!******************************!*\
  !*** external ["wp","i18n"] ***!
  \******************************/
/***/ (function(module) {

module.exports = window["wp"]["i18n"];

/***/ }),

/***/ "./src/blocks/input/block.json":
/*!*************************************!*\
  !*** ./src/blocks/input/block.json ***!
  \*************************************/
/***/ (function(module) {

module.exports = JSON.parse('{"$schema":"https://schemas.wp.org/trunk/block.json","apiVersion":2,"name":"dragblock/input","version":"0.1.0","title":"Input","category":"dragblock-form","icon":"nametag","description":"Insert a flexible input field","keywords":["input","text input","checkbox","radio","email","address","phone"],"supports":{"html":false},"textdomain":"dragblock","editorScript":"file:./index.js","editorStyle":"file:./index.css","style":"file:./style-index.css"}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
!function() {
/*!***********************************!*\
  !*** ./src/blocks/input/index.js ***!
  \***********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_blocks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/blocks */ "@wordpress/blocks");
/* harmony import */ var _wordpress_blocks__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_blocks__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./src/blocks/input/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./src/blocks/input/save.js");
/* harmony import */ var _block_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./block.json */ "./src/blocks/input/block.json");




(0,_wordpress_blocks__WEBPACK_IMPORTED_MODULE_0__.registerBlockType)(_block_json__WEBPACK_IMPORTED_MODULE_3__.name, {
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
});
}();
/******/ })()
;
