/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@wordpress/icons/build-module/library/chevron-left.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@wordpress/icons/build-module/library/chevron-left.js ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/primitives */ "@wordpress/primitives");
/* harmony import */ var _wordpress_primitives__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__);

/**
 * WordPress dependencies
 */

const chevronLeft = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__.SVG, {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24"
}, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__.Path, {
  d: "M14.6 7l-1.2-1L8 12l5.4 6 1.2-1-4.6-5z"
}));
/* harmony default export */ __webpack_exports__["default"] = (chevronLeft);


/***/ }),

/***/ "./node_modules/@wordpress/icons/build-module/library/trash.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@wordpress/icons/build-module/library/trash.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/primitives */ "@wordpress/primitives");
/* harmony import */ var _wordpress_primitives__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__);

/**
 * WordPress dependencies
 */

const trash = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__.SVG, {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24"
}, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__.Path, {
  d: "M20 5h-5.7c0-1.3-1-2.3-2.3-2.3S9.7 3.7 9.7 5H4v2h1.5v.3l1.7 11.1c.1 1 1 1.7 2 1.7h5.7c1 0 1.8-.7 2-1.7l1.7-11.1V7H20V5zm-3.2 2l-1.7 11.1c0 .1-.1.2-.3.2H9.1c-.1 0-.3-.1-.3-.2L7.2 7h9.6z"
}));
/* harmony default export */ __webpack_exports__["default"] = (trash);


/***/ }),

/***/ "./node_modules/@wordpress/icons/build-module/library/update.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@wordpress/icons/build-module/library/update.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/primitives */ "@wordpress/primitives");
/* harmony import */ var _wordpress_primitives__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__);

/**
 * WordPress dependencies
 */

const update = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__.SVG, {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24"
}, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_primitives__WEBPACK_IMPORTED_MODULE_1__.Path, {
  d: "m11.3 17.2-5-5c-.1-.1-.1-.3 0-.4l2.3-2.3-1.1-1-2.3 2.3c-.7.7-.7 1.8 0 2.5l5 5H7.5v1.5h5.3v-5.2h-1.5v2.6zm7.5-6.4-5-5h2.7V4.2h-5.2v5.2h1.5V6.8l5 5c.1.1.1.3 0 .4l-2.3 2.3 1.1 1.1 2.3-2.3c.6-.7.6-1.9-.1-2.5z"
}));
/* harmony default export */ __webpack_exports__["default"] = (update);


/***/ }),

/***/ "./src/applications/font-library/client/constants.js":
/*!***********************************************************!*\
  !*** ./src/applications/font-library/client/constants.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_DEMO_TYPE: function() { return /* binding */ DEFAULT_DEMO_TYPE; },
/* harmony export */   DEMO_DEFAULTS: function() { return /* binding */ DEMO_DEFAULTS; }
/* harmony export */ });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);

const DEFAULT_HEADING_TEXT = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('The quick brown fox jumps over the lazy dog.', 'dragblock');
const DEFAULT_SENTENCE_TEXT = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Incredible as it may seem, I believe that the Aleph of Garay Street was a false Aleph.', 'dragblock');
const DEFAULT_PARAGRAPH_TEXT = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)("First a glass of pseudo-cognac, he ordered, and then down you dive into the cellar. Let me warn you, you'll have to lie flat on your back. Total darkness, total immobility, and a certain ocular adjustment will also be necessary. From the floor, you must focus your eyes on the nineteenth step. Once I leave you, I'll lower the trapdoor and you'll be quite alone. You needn't fear the rodents very much though I know you will. In a minute or two, you'll see the Aleph, the microcosm of the alchemists and Kabbalists, our true proverbial friend, the multum in parvo!", 'dragblock');
const DEFAULT_DEMO_TYPE = 'sentence';
const DEMO_DEFAULTS = {
  heading: {
    text: DEFAULT_HEADING_TEXT,
    size: 30,
    lineHeight: 1.1,
    margin: '0.5em 0',
    component: 'h2'
  },
  sentence: {
    text: DEFAULT_SENTENCE_TEXT,
    size: 20,
    lineHeight: 1.3,
    margin: '0.5em 0',
    component: 'p'
  },
  paragraph: {
    text: DEFAULT_PARAGRAPH_TEXT,
    size: 16,
    lineHeight: 1.5,
    margin: '0.5em 0',
    component: 'p'
  }
};

/***/ }),

/***/ "./src/applications/font-library/client/demo-text-input/axis-range-control.js":
/*!************************************************************************************!*\
  !*** ./src/applications/font-library/client/demo-text-input/axis-range-control.js ***!
  \************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__);



function AxisRangeControl({
  axis,
  setAxisCurrentValue
}) {
  const handleChange = val => {
    setAxisCurrentValue(axis.tag, val);
  };
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.RangeControl, {
    label: axis.tag + ' ' + (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('font axis:', 'dragblock'),
    name: `font-axis-${axis.tag}`,
    id: `font-axis-${axis.tag}`,
    min: parseInt(axis.minValue),
    max: parseInt(axis.maxValue),
    value: parseInt(axis.currentValue),
    onChange: handleChange,
    step: 1
  }));
}
/* harmony default export */ __webpack_exports__["default"] = (AxisRangeControl);

/***/ }),

/***/ "./src/applications/font-library/client/demo-text-input/demo.js":
/*!**********************************************************************!*\
  !*** ./src/applications/font-library/client/demo-text-input/demo.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fonts_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../fonts-context */ "./src/applications/font-library/client/fonts-context.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "./src/applications/font-library/client/constants.js");




function Demo({
  style
}) {
  const {
    demoText,
    demoType,
    demoFontSize
  } = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useContext)(_fonts_context__WEBPACK_IMPORTED_MODULE_1__.ManageFontsContext);
  const Component = _constants__WEBPACK_IMPORTED_MODULE_2__.DEMO_DEFAULTS[demoType].component;
  const demoStyles = {
    ...style,
    fontSize: `${demoFontSize}px`,
    lineHeight: _constants__WEBPACK_IMPORTED_MODULE_2__.DEMO_DEFAULTS[demoType].lineHeight,
    margin: _constants__WEBPACK_IMPORTED_MODULE_2__.DEMO_DEFAULTS[demoType].margin
  };
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(Component, {
    style: demoStyles
  }, demoText));
}
/* harmony default export */ __webpack_exports__["default"] = (Demo);

/***/ }),

/***/ "./src/applications/font-library/client/demo-text-input/index.js":
/*!***********************************************************************!*\
  !*** ./src/applications/font-library/client/demo-text-input/index.js ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _fonts_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../fonts-context */ "./src/applications/font-library/client/fonts-context.js");
/* harmony import */ var _wordpress_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/icons */ "./node_modules/@wordpress/icons/build-module/library/update.js");
/* harmony import */ var _demo_text_input_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./demo-text-input.css */ "./src/applications/font-library/client/demo-text-input/demo-text-input.css");
/* harmony import */ var _variable_controls__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./variable-controls */ "./src/applications/font-library/client/demo-text-input/variable-controls.js");








function DemoTextInput({
  axes,
  setAxes,
  resetAxes
}) {
  const {
    demoText,
    handleDemoTextChange,
    demoType,
    handleDemoTypeChange,
    demoFontSize,
    handleDemoFontSizeChange,
    resetDefaults
  } = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useContext)(_fonts_context__WEBPACK_IMPORTED_MODULE_3__.ManageFontsContext);
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "demo-text-input"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "container"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "controls"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "standard-controls"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.SelectControl, {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Preview type', 'dragblock'),
    onChange: handleDemoTypeChange,
    value: demoType
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("option", {
    value: "heading"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Heading', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("option", {
    value: "sentence"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Sentence', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("option", {
    value: "paragraph"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Paragraph', 'dragblock'))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.__experimentalInputControl, {
    label: "Demo text",
    value: demoText,
    onChange: handleDemoTextChange
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.RangeControl, {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Font size (px)', 'dragblock'),
    value: demoFontSize,
    onChange: handleDemoFontSizeChange,
    min: 8,
    max: 140,
    withInputField: true
  }))), !!axes && !!Object.keys(axes).length && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "extra-controls"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_variable_controls__WEBPACK_IMPORTED_MODULE_5__["default"], {
    axes: axes,
    setAxes: setAxes
  }))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.Button, {
    variant: "secondary",
    icon: _wordpress_icons__WEBPACK_IMPORTED_MODULE_6__["default"],
    onClick: () => {
      resetDefaults('sentence');
      handleDemoTypeChange('sentence');
      resetAxes();
    }
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Reset', 'dragblock')))));
}
/* harmony default export */ __webpack_exports__["default"] = (DemoTextInput);

/***/ }),

/***/ "./src/applications/font-library/client/demo-text-input/utils.js":
/*!***********************************************************************!*\
  !*** ./src/applications/font-library/client/demo-text-input/utils.js ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   variableAxesToCss: function() { return /* binding */ variableAxesToCss; }
/* harmony export */ });
function variableAxesToCss(axes) {
  if (!axes || !Object.keys(axes).length) {
    return '';
  }
  const fontVariationSettings = Object.keys(axes).map(key => `'${axes[key].tag}' ${axes[key].currentValue}`) // convert to CSS format
  .join(', ');
  return fontVariationSettings;
}

/***/ }),

/***/ "./src/applications/font-library/client/demo-text-input/variable-controls.js":
/*!***********************************************************************************!*\
  !*** ./src/applications/font-library/client/demo-text-input/variable-controls.js ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _axis_range_control__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./axis-range-control */ "./src/applications/font-library/client/demo-text-input/axis-range-control.js");


function VariableControls({
  axes,
  setAxes
}) {
  const handleAxisCurrentValueChange = (axisTag, value) => {
    setAxes({
      ...axes,
      [axisTag]: {
        ...axes[axisTag],
        currentValue: value
      }
    });
  };
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, axes && Object.keys(axes).length && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, Object.keys(axes).map(key => (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_axis_range_control__WEBPACK_IMPORTED_MODULE_1__["default"], {
    axis: axes[key],
    key: `axis-range-${key}`,
    setAxisCurrentValue: handleAxisCurrentValueChange
  }))));
}
/* harmony default export */ __webpack_exports__["default"] = (VariableControls);

/***/ }),

/***/ "./src/applications/font-library/client/fonts-context.js":
/*!***************************************************************!*\
  !*** ./src/applications/font-library/client/fonts-context.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ManageFontsContext: function() { return /* binding */ ManageFontsContext; },
/* harmony export */   ManageFontsProvider: function() { return /* binding */ ManageFontsProvider; }
/* harmony export */ });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "./src/applications/font-library/client/constants.js");



const ManageFontsContext = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createContext)();
function ManageFontsProvider({
  children
}) {
  const [demoType, setDemoType] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(localStorage.getItem('cbt_default-demo-type') || _constants__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_DEMO_TYPE);
  const [demoText, setDemoText] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(localStorage.getItem('cbt_default-demo-text') || _constants__WEBPACK_IMPORTED_MODULE_1__.DEMO_DEFAULTS[demoType].text);
  const [demoFontSize, setDemoFontSize] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(parseInt(localStorage.getItem('cbt_default-demo-font-size')) || _constants__WEBPACK_IMPORTED_MODULE_1__.DEMO_DEFAULTS[demoType].size);
  const [axes, setAxes] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const handleAxesChange = (tag, value) => {
    setAxes({
      ...axes,
      [tag]: {
        ...axes[tag],
        currentValue: value
      }
    });
  };
  const handleDemoTextChange = newDemoText => {
    setDemoText(newDemoText);
    localStorage.setItem('cbt_default-demo-text', newDemoText);
  };
  const handleDemoTypeChange = newDemoType => {
    setDemoType(newDemoType);
    localStorage.setItem('cbt_default-demo-type', newDemoType);
    resetDefaults(newDemoType);
  };
  const handleDemoFontSizeChange = newDemoFontSize => {
    setDemoFontSize(newDemoFontSize);
    localStorage.setItem('cbt_default-demo-font-size', newDemoFontSize);
  };
  const resetDefaults = newDemoType => {
    handleDemoTextChange(_constants__WEBPACK_IMPORTED_MODULE_1__.DEMO_DEFAULTS[newDemoType || demoType].text);
    handleDemoFontSizeChange(_constants__WEBPACK_IMPORTED_MODULE_1__.DEMO_DEFAULTS[newDemoType || demoType].size);
  };

  // The list of families that are open (showing the list of font faces) in the font manager.
  const [familiesOpen, setFamiliesOpen] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(JSON.parse(localStorage.getItem('cbt_families-open')) || []);
  const handleToggleFamily = familyName => {
    let newFamiliesOpen = [];
    if (familiesOpen.includes(familyName)) {
      newFamiliesOpen = familiesOpen.filter(name => name !== familyName);
    } else {
      newFamiliesOpen = [...familiesOpen, familyName];
    }
    setFamiliesOpen(newFamiliesOpen);
    localStorage.setItem('cbt_families-open', JSON.stringify(newFamiliesOpen));
  };
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(ManageFontsContext.Provider, {
    value: {
      demoText,
      handleDemoTextChange,
      resetDefaults,
      demoType,
      handleDemoTypeChange,
      demoFontSize,
      handleDemoFontSizeChange,
      familiesOpen,
      handleToggleFamily,
      axes,
      handleAxesChange
    }
  }, children);
}

/***/ }),

/***/ "./src/applications/font-library/client/fonts-page-layout/index.js":
/*!*************************************************************************!*\
  !*** ./src/applications/font-library/client/fonts-page-layout/index.js ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fonts_page_layout_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fonts-page-layout.css */ "./src/applications/font-library/client/fonts-page-layout/fonts-page-layout.css");


function FontsPageLayout(props) {
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "fonts-page-layout"
  }, props.children);
}
/* harmony default export */ __webpack_exports__["default"] = (FontsPageLayout);

/***/ }),

/***/ "./src/applications/font-library/client/fonts-sidebar/index.js":
/*!*********************************************************************!*\
  !*** ./src/applications/font-library/client/fonts-sidebar/index.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils */ "./src/applications/font-library/client/utils.js");
/* harmony import */ var _fonts_sidebar_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fonts-sidebar.css */ "./src/applications/font-library/client/fonts-sidebar/fonts-sidebar.css");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/icons */ "./node_modules/@wordpress/icons/build-module/library/trash.js");







function FontsSidebar({
  title,
  fontsOutline,
  handleDeleteFontFace,
  handleDeleteFontFamily
}) {
  const [fileSizes, setFileSizes] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const flatfontsOutline = Object.keys(fontsOutline).map(family => {
    return fontsOutline[family].faces.map(face => {
      return {
        family,
        weight: face.weight,
        style: face.style,
        src: face.src
      };
    });
  }).flat();
  (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const promises = flatfontsOutline.map(face => {
      return fetch(face.src, {
        method: 'HEAD'
      });
    });
    Promise.all(promises).then(responses => {
      const sizes = {};
      responses.forEach(response => {
        sizes[response.url] = response.headers.get('content-length');
      });
      setFileSizes(sizes);
    });
  }, [fontsOutline]);
  const variantsCount = Object.keys(fontsOutline).reduce((acc, family) => {
    return acc + fontsOutline[family].faces.length;
  }, 0);
  const getFileSize = url => {
    return fileSizes[url] ? (0,_utils__WEBPACK_IMPORTED_MODULE_2__.bytesToSize)(fileSizes[url]) : null;
  };
  const totalSize = (0,_utils__WEBPACK_IMPORTED_MODULE_2__.bytesToSize)(flatfontsOutline.reduce((acc, face) => {
    return acc + parseInt(fileSizes[face.src]);
  }, 0));
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "sidebar"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "sidebar-container"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "variants-outline"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h2", null, title), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h3", null, fontsOutline.family), !!fontsOutline && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "variants-list"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "content"
  }, Object.keys(fontsOutline).map((key, i) => (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "variants-family",
    key: `variants-family-${i}`
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "header"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", {
    className: "name"
  }, fontsOutline[key].family, ' '), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", {
    className: "variants"
  }, !!fontsOutline[key].faces.length && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, "(", ' ', fontsOutline[key].faces.length, ' ', (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__._n)('Variant', 'Variants', fontsOutline[key].faces.length, 'dragblock'), ' ', ")")), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__.Button, {
    icon: _wordpress_icons__WEBPACK_IMPORTED_MODULE_5__["default"],
    iconSize: 15,
    isSmall: true,
    onClick: () => handleDeleteFontFamily(fontsOutline[key].family)
  }))), fontsOutline[key].faces.map((face, faceIndex) => (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "variant-row",
    key: `selected-variant-${faceIndex}`
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "variant"
  }, face.weight, ' ', face.style), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "size"
  }, getFileSize(face.src)), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__.Button, {
    onClick: () => handleDeleteFontFace(fontsOutline[key].family, face.weight, face.style),
    icon: _wordpress_icons__WEBPACK_IMPORTED_MODULE_5__["default"],
    iconSize: 15,
    isSmall: true
  }))))))))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "variants-total"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "variant"
  }, variantsCount, ' ', (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__._n)('Variant', 'Variants', variantsCount, 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "size"
  }, totalSize)))));
}
/* harmony default export */ __webpack_exports__["default"] = (FontsSidebar);

/***/ }),

/***/ "./src/applications/font-library/client/google-fonts/font-variant.js":
/*!***************************************************************************!*\
  !*** ./src/applications/font-library/client/google-fonts/font-variant.js ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _demo_text_input_demo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../demo-text-input/demo */ "./src/applications/font-library/client/demo-text-input/demo.js");



function FontVariant({
  font,
  variant,
  isSelected,
  handleToggle
}) {
  const style = variant.includes('italic') ? 'italic' : 'normal';
  const weight = variant === 'regular' || variant === 'italic' ? '400' : variant.replace('italic', '');
  // Force https because sometimes Google Fonts API returns http instead of https
  const variantUrl = font.files[variant].replace('http://', 'https://');
  const previewStyles = {
    fontFamily: font.family,
    fontStyle: style,
    fontWeight: weight
  };
  (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const newFont = new FontFace(font.family, `url( ${variantUrl} )`, {
      style,
      weight
    });
    newFont.load().then(function (loadedFace) {
      document.fonts.add(loadedFace);
    }).catch(function (error) {
      // TODO: show error in the UI
      // eslint-disable-next-line
      console.error(error);
    });
  }, [font, variant]);
  const formattedFontFamily = font.family.toLowerCase().replace(' ', '-');
  const fontId = `${formattedFontFamily}-${variant}`;
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("tr", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: ""
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "checkbox",
    name: "google-font-variant",
    id: fontId,
    value: variant,
    checked: isSelected,
    onChange: handleToggle
  })), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: ""
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("label", {
    htmlFor: fontId
  }, weight)), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: ""
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("label", {
    htmlFor: fontId
  }, style)), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: "demo-cell"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("label", {
    htmlFor: fontId
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_demo_text_input_demo__WEBPACK_IMPORTED_MODULE_1__["default"], {
    style: previewStyles
  }))));
}
/* harmony default export */ __webpack_exports__["default"] = (FontVariant);

/***/ }),

/***/ "./src/applications/font-library/client/google-fonts/index.js":
/*!********************************************************************!*\
  !*** ./src/applications/font-library/client/google-fonts/index.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_core_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/core-data */ "@wordpress/core-data");
/* harmony import */ var _wordpress_core_data__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_core_data__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var lib_font__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lib-font */ "./node_modules/lib-font/lib-font.js");
/* harmony import */ var _fonts_sidebar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../fonts-sidebar */ "./src/applications/font-library/client/fonts-sidebar/index.js");
/* harmony import */ var _font_variant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./font-variant */ "./src/applications/font-library/client/google-fonts/font-variant.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils */ "./src/applications/font-library/client/utils.js");
/* harmony import */ var _demo_text_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../demo-text-input */ "./src/applications/font-library/client/demo-text-input/index.js");
/* harmony import */ var _fonts_page_layout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../fonts-page-layout */ "./src/applications/font-library/client/fonts-page-layout/index.js");
/* harmony import */ var _google_fonts_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./google-fonts.css */ "./src/applications/font-library/client/google-fonts/google-fonts.css");
/* harmony import */ var _manage_fonts_back_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../manage-fonts/back-button */ "./src/applications/font-library/client/manage-fonts/back-button.js");














const EMPTY_SELECTION_DATA = {};

// const selectionDataExample = {
// 	"Abel sans": {
// 		"family": "Abel sans",
// 		"faces": [
// 			{
// 				"weight": "400",
// 				"style": "normal",
// 				"src": "https://fonts.gstatic.com/s/abel/v11/MwQ5bhbm2POE6VhLPJp6qGI.ttf"
// 			}
// 		]
// 	}
// };

function GoogleFonts() {
  const [googleFontsData, setGoogleFontsData] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const [selectedFont, setSelectedFont] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const [selectedFontCredits, setSelectedFontCredits] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const [selectionData, setSelectionData] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(EMPTY_SELECTION_DATA);

  // pickup the nonce from the input printed in the server
  const nonce = document.querySelector('#nonce').value;
  const handleToggleAllVariants = family => {
    const existingFamily = selectionData[family];
    if (existingFamily && !!existingFamily?.faces?.length) {
      const {
        [family]: removedFamily,
        ...rest
      } = selectionData;
      setSelectionData(rest);
    } else {
      const newFamily = {
        family,
        faces: selectedFont.variants.map(variant => {
          return {
            weight: (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getWeightFromGoogleVariant)(variant),
            style: (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getStyleFromGoogleVariant)(variant),
            src: (0,_utils__WEBPACK_IMPORTED_MODULE_8__.forceHttps)(selectedFont.files[variant])
          };
        })
      };
      setSelectionData({
        ...selectionData,
        [family]: newFamily
      });
    }
  };
  const isVariantSelected = (family, weight, style) => {
    const existingFamily = selectionData[family];
    if (existingFamily) {
      const existingFace = existingFamily.faces.find(face => {
        return face.weight === weight && face.style === style;
      });
      return !!existingFace;
    }
    return false;
  };
  const addVariant = (family, weight, style) => {
    const existingFamily = selectionData[family];
    const variant = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getGoogleVariantFromStyleAndWeight)(style, weight);
    if (existingFamily) {
      setSelectionData({
        ...selectionData,
        [family]: {
          ...existingFamily,
          faces: [...(existingFamily?.faces || []), {
            weight,
            style,
            src: (0,_utils__WEBPACK_IMPORTED_MODULE_8__.forceHttps)(selectedFont.files[variant])
          }]
        }
      });
    } else {
      setSelectionData({
        ...selectionData,
        [family]: {
          family,
          faces: [{
            weight,
            style,
            src: (0,_utils__WEBPACK_IMPORTED_MODULE_8__.forceHttps)(selectedFont.files[variant])
          }]
        }
      });
    }
  };
  const removeVariant = (family, weight, style) => {
    const existingFamily = selectionData[family];
    const newFaces = existingFamily.faces.filter(face => !(face.weight === weight && face.style === style));
    if (!newFaces.length) {
      const {
        [family]: removedFamily,
        ...rest
      } = selectionData;
      setSelectionData(rest);
    } else {
      setSelectionData({
        ...selectionData,
        [family]: {
          ...existingFamily,
          faces: newFaces
        }
      });
    }
  };
  const handleToggleVariant = (family, weight, style) => {
    if (isVariantSelected(family, weight, style)) {
      removeVariant(family, weight, style);
    } else {
      addVariant(family, weight, style);
    }
  };

  // Load google fonts data
  (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    (async () => {
      const responseData = await fetch(dragBlockFontLib.googleFontsDataUrl);
      const parsedData = await responseData.json();
      setGoogleFontsData(parsedData);
    })();
  }, []);
  const theme = (0,_wordpress_data__WEBPACK_IMPORTED_MODULE_2__.useSelect)(select => {
    return select(_wordpress_core_data__WEBPACK_IMPORTED_MODULE_3__.store).getCurrentTheme();
  }, null);
  const getFontCredits = selectedFontObj => {
    const fontObj = new lib_font__WEBPACK_IMPORTED_MODULE_5__.Font(selectedFontObj.family);
    let fontError = false;

    // Force font file to be https
    let fontFile = Object.values(selectedFontObj.files)[0];
    if (fontFile.includes('http://')) {
      fontFile = fontFile.replace('http://', 'https://');
    }

    // Load font file
    fontObj.src = fontFile;
    fontObj.onerror = event => {
      // eslint-disable-next-line no-console
      console.error(event);
      fontError = true;
    };
    if (!fontError) {
      fontObj.onload = event => getFontData(event);
      function getFontData(event) {
        const font = event.detail.font;
        const {
          name
        } = font.opentype.tables;
        const fontCredits = {
          copyright: name.get(0),
          source: name.get(11),
          license: name.get(13),
          licenseURL: name.get(14)
        };
        setSelectedFontCredits(fontCredits);
      }
    }
  };
  const handleSelectChange = value => {
    setSelectedFont(googleFontsData.items[value]);
    getFontCredits(googleFontsData.items[value]);
  };
  let selectedFontFamilyId = '';
  if (selectedFont) {
    selectedFontFamilyId = selectedFont.family.toLowerCase().replace(' ', '-');
  }
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_fonts_page_layout__WEBPACK_IMPORTED_MODULE_10__["default"], null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("main", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("header", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_manage_fonts_back_button__WEBPACK_IMPORTED_MODULE_12__["default"], null), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h1", {
    className: "wp-heading-inline"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Add Google fonts', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Add Google fonts assets and font face definitions to the DragBlock\'s font library', 'dragblock'), ' ')), !googleFontsData?.items && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__.Spinner, null), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Loading Google fonts data…', 'dragblock'))), googleFontsData?.items && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "select-font"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__.SelectControl, {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Select Font', 'dragblock'),
    name: "google-font",
    onChange: handleSelectChange,
    size: "__unstable-large"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("option", {
    value: null
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Select a font…', 'dragblock')), googleFontsData.items.map((font, index) => (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("option", {
    value: index,
    key: `option${index}`
  }, font.family)))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_demo_text_input__WEBPACK_IMPORTED_MODULE_9__["default"], null), selectedFont && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Select the font variants you want to include:', 'dragblock')), selectedFont && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("table", {
    className: "wp-list-table widefat striped table-view-list",
    id: "google-fonts-table"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("thead", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("tr", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: ""
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "checkbox",
    id: `select-all-${selectedFontFamilyId}`,
    onChange: () => handleToggleAllVariants(selectedFont.family),
    checked: selectedFont.variants.length === selectionData[selectedFont.family]?.faces?.length
  })), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: ""
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("label", {
    htmlFor: `select-all-${selectedFontFamilyId}`
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Weight', 'dragblock'))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: ""
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("label", {
    htmlFor: `select-all-${selectedFontFamilyId}`
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Style', 'dragblock'))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: ""
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("label", {
    htmlFor: `select-all-${selectedFontFamilyId}`
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Preview', 'dragblock'))))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("tbody", null, selectedFont.variants.map((variant, i) => (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_font_variant__WEBPACK_IMPORTED_MODULE_7__["default"], {
    font: selectedFont,
    variant: variant,
    key: `font-variant-${i}`,
    isSelected: isVariantSelected(selectedFont.family, (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getWeightFromGoogleVariant)(variant), (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getStyleFromGoogleVariant)(variant)),
    handleToggle: () => handleToggleVariant(selectedFont.family, (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getWeightFromGoogleVariant)(variant), (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getStyleFromGoogleVariant)(variant))
  })))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("form", {
    encType: "multipart/form-data",
    action: "",
    method: "POST"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "hidden",
    name: "selection-data",
    value: JSON.stringify(Object.values(selectionData))
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "hidden",
    name: "font-credits",
    value: JSON.stringify(selectedFontCredits)
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__.Button, {
    variant: "primary",
    type: "submit",
    disabled: Object.values(selectionData).length === 0
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Add Google fonts', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "hidden",
    name: "nonce",
    value: nonce
  })))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_fonts_sidebar__WEBPACK_IMPORTED_MODULE_6__["default"], {
    title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Selected Variants', 'dragblock'),
    fontsOutline: selectionData,
    handleDeleteFontFace: handleToggleVariant,
    handleDeleteFontFamily: handleToggleAllVariants
  }));
}
/* harmony default export */ __webpack_exports__["default"] = (GoogleFonts);

/***/ }),

/***/ "./src/applications/font-library/client/local-fonts/index.js":
/*!*******************************************************************!*\
  !*** ./src/applications/font-library/client/local-fonts/index.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _upload_font_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./upload-font-form */ "./src/applications/font-library/client/local-fonts/upload-font-form.js");
/* harmony import */ var _local_fonts_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./local-fonts.css */ "./src/applications/font-library/client/local-fonts/local-fonts.css");
/* harmony import */ var _demo_text_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../demo-text-input */ "./src/applications/font-library/client/demo-text-input/index.js");
/* harmony import */ var _demo_text_input_demo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../demo-text-input/demo */ "./src/applications/font-library/client/demo-text-input/demo.js");
/* harmony import */ var _demo_text_input_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../demo-text-input/utils */ "./src/applications/font-library/client/demo-text-input/utils.js");
/* harmony import */ var _manage_fonts_back_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../manage-fonts/back-button */ "./src/applications/font-library/client/manage-fonts/back-button.js");









const INITIAL_FORM_DATA = {
  file: null,
  name: null,
  weight: null,
  style: null
};
function LocalFonts() {
  const [formData, setFormData] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(INITIAL_FORM_DATA);
  const [axes, setAxes] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const resetFormData = () => {
    setFormData(INITIAL_FORM_DATA);
  };
  const resetAxes = () => {
    const newAxes = Object.keys(axes).reduce((acc, axisTag) => {
      acc[axisTag] = {
        ...axes[axisTag],
        currentValue: axes[axisTag].defaultValue
      };
      return acc;
    }, {});
    setAxes(newAxes);
  };
  const isFormValid = () => {
    return formData.file && formData.name && formData.weight && formData.style;
  };
  const demoStyle = () => {
    if (!isFormValid()) {
      return {};
    }
    const style = {
      fontFamily: formData.name,
      fontWeight: formData.weight,
      fontStyle: formData.style
    };
    if (formData.variable) {
      style.fontVariationSettings = (0,_demo_text_input_utils__WEBPACK_IMPORTED_MODULE_6__.variableAxesToCss)(axes);
    }
    return style;
  };

  // load the local font in the browser to make the preview work
  const onFormDataChange = async () => {
    if (!isFormValid()) {
      return;
    }
    const data = await formData.file.arrayBuffer();
    const newFont = new FontFace(formData.name, data, {
      style: formData.style,
      weight: formData.weight
    });
    newFont.load().then(function (loadedFace) {
      document.fonts.add(loadedFace);
    }).catch(function (error) {
      // TODO: show error in the UI
      // eslint-disable-next-line
      console.error(error);
    });
  };
  (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    onFormDataChange();
  }, [formData]);
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "layout"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("main", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("header", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_manage_fonts_back_button__WEBPACK_IMPORTED_MODULE_7__["default"], null), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h1", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Upload Local Fonts', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Add local fonts assets and font face definitions to the DragBlock\'s font library', 'dragblock'))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_upload_font_form__WEBPACK_IMPORTED_MODULE_2__["default"], {
    isFormValid: isFormValid,
    formData: formData,
    setFormData: setFormData,
    resetFormData: resetFormData,
    setAxes: setAxes
  })), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "preview"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h2", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Font file preview', 'dragblock')), isFormValid() ? (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_demo_text_input__WEBPACK_IMPORTED_MODULE_4__["default"], {
    axes: axes,
    setAxes: setAxes,
    resetAxes: resetAxes
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Demo:', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_demo_text_input_demo__WEBPACK_IMPORTED_MODULE_5__["default"], {
    style: demoStyle()
  })) : (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Load a font file to preview it.', 'dragblock'))));
}
/* harmony default export */ __webpack_exports__["default"] = (LocalFonts);

/***/ }),

/***/ "./src/applications/font-library/client/local-fonts/upload-font-form.js":
/*!******************************************************************************!*\
  !*** ./src/applications/font-library/client/local-fonts/upload-font-form.js ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lib_font__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lib-font */ "./node_modules/lib-font/lib-font.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _demo_text_input_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../demo-text-input/utils */ "./src/applications/font-library/client/demo-text-input/utils.js");





function UploadFontForm({
  formData,
  setFormData,
  resetFormData,
  isFormValid,
  setAxes
}) {
  // pickup the nonce from the input printed in the server
  const nonce = document.querySelector('#nonce').value;
  const onFileSelectChange = event => {
    const file = event.target.files[0];
    if (!file) {
      resetFormData();
      return;
    }

    // Use FileReader to, well, read the file
    const reader = new FileReader();
    reader.readAsArrayBuffer(file);
    reader.onload = () => {
      // Create a font object
      const fontObj = new lib_font__WEBPACK_IMPORTED_MODULE_2__.Font('Uploaded Font');

      // Pass the buffer, and the original filename
      fontObj.fromDataBuffer(reader.result, file.name);
      fontObj.onload = onloadEvent => {
        // Map the details LibFont gathered from the font to the
        // "font" variable
        const font = onloadEvent.detail.font;

        // From all the OpenType tables in the font, take the "name"
        // table so we can inspect it further
        const {
          name
        } = font.opentype.tables;

        // From the name table, take the entry with ID "1". This is
        // the Font Family name. More info and names you can grab:
        // https://docs.microsoft.com/en-us/typography/opentype/spec/name

        const fontName = name.get(1);
        const isItalic = name.get(2).toLowerCase().includes('italic');
        const fontWeight = font.opentype.tables['OS/2'].usWeightClass || 'normal';

        // Variable fonts info
        const isVariable = !!font.opentype.tables.fvar;
        const weightAxis = isVariable && font.opentype.tables.fvar.axes.find(({
          tag
        }) => tag === 'wght');
        const weightRange = !!weightAxis ? `${weightAxis.minValue} ${weightAxis.maxValue}` : null;
        const axes = isVariable ? font.opentype.tables.fvar.axes.reduce((acc, {
          tag,
          minValue,
          defaultValue,
          maxValue
        }) => {
          acc[tag] = {
            tag,
            minValue,
            defaultValue,
            maxValue,
            currentValue: defaultValue
          };
          return acc;
        }, {}) : {};
        const fontCredits = {
          copyright: name.get(0),
          source: name.get(11),
          license: name.get(13),
          licenseURL: name.get(14)
        };
        setFormData({
          file,
          name: fontName,
          style: isItalic ? 'italic' : 'normal',
          weight: !!weightAxis ? weightRange : fontWeight,
          variable: isVariable,
          fontCredits
        });
        setAxes(axes);
      };
    };
  };
  const fontVariationSettings = (0,_demo_text_input_utils__WEBPACK_IMPORTED_MODULE_4__.variableAxesToCss)(formData.axes);
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("form", {
    method: "POST",
    id: "font-upload-form",
    action: "",
    encType: "multipart/form-data"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "hidden",
    name: "nonce",
    value: nonce
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "form-group"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("label", {
    htmlFor: "font-file"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Font file:', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "file",
    name: "font-file",
    id: "font-file",
    onChange: onFileSelectChange,
    accept: ".otf, .ttf, .woff, .woff2"
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("small", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('.otf, .ttf, .woff, .woff2 file extensions supported', 'dragblock'))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h4", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Font face definition for this font file:', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "form-group"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.__experimentalInputControl, {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Font name:', 'dragblock'),
    type: "text",
    name: "font-name",
    id: "font-name",
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Font name', 'dragblock'),
    value: formData.name || '',
    onChange: val => setFormData({
      ...formData,
      name: val
    })
  })), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "form-group"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.SelectControl, {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Font style:', 'dragblock'),
    name: "font-style",
    id: "font-style",
    value: formData.style || '',
    onChange: val => setFormData({
      ...formData,
      style: val
    })
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("option", {
    value: "normal"
  }, "Normal"), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("option", {
    value: "italic"
  }, "Italic"))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "form-group"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.__experimentalInputControl, {
    label: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Font weight:', 'dragblock'),
    type: "text",
    name: "font-weight",
    id: "font-weight",
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Font weight:', 'dragblock'),
    value: formData.weight || '',
    onChange: val => setFormData({
      ...formData,
      weight: val
    })
    // Disable the input if the font is a variable font with the wght axis
  })), formData.variable && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "hidden",
    name: "font-variation-settings",
    value: fontVariationSettings
  })), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.Button, {
    variant: "primary",
    type: "submit",
    disabled: !isFormValid(),
    form: "font-upload-form"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Upload Font', 'dragblock')));
}
/* harmony default export */ __webpack_exports__["default"] = (UploadFontForm);

/***/ }),

/***/ "./src/applications/font-library/client/manage-fonts/back-button.js":
/*!**************************************************************************!*\
  !*** ./src/applications/font-library/client/manage-fonts/back-button.js ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/icons */ "./node_modules/@wordpress/icons/build-module/library/chevron-left.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);




function BackButton() {
  const {
    adminUrl,
    fontLibSlug
  } = dragBlockFontLib;
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.Button, {
    varint: "secondary",
    icon: _wordpress_icons__WEBPACK_IMPORTED_MODULE_3__["default"],
    href: `${adminUrl}admin.php?page=${fontLibSlug}`,
    iconSize: 20,
    style: {
      padding: '0',
      height: '1.5rem',
      minWidth: '1.5rem',
      marginLeft: '-.5rem'
    },
    "aria-label": (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Back to manage fonts', 'dragblock')
  });
}
/* harmony default export */ __webpack_exports__["default"] = (BackButton);

/***/ }),

/***/ "./src/applications/font-library/client/manage-fonts/confirm-delete-modal.js":
/*!***********************************************************************************!*\
  !*** ./src/applications/font-library/client/manage-fonts/confirm-delete-modal.js ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);



function ConfirmDeleteModal({
  isOpen,
  onConfirm,
  onCancel,
  fontToDelete
}) {
  const deleteFontFaceMessage = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.sprintf)(
  // translators: %1$s: Font Style, %2$s: Font Weight, %3$s: Font Family
  (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)(`Are you sure you want to delete "%1$s - %2$s" variant of "%3$s" from the DragBlock\'s font library?`, 'dragblock'), fontToDelete?.weight, fontToDelete?.style, fontToDelete?.fontFamily);
  const deleteFontFamilyMessage = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.sprintf)(
  // translators: %s: Font Family
  (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)(`Are you sure you want to delete "%s" from the DragBlock\'s font library?`, 'dragblock'), fontToDelete?.fontFamily);
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.__experimentalConfirmDialog, {
    isOpen: isOpen,
    onConfirm: onConfirm,
    onCancel: onCancel
  }, fontToDelete?.weight !== undefined && fontToDelete.style !== undefined ? (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h3", null, deleteFontFaceMessage) : (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h3", null, deleteFontFamilyMessage), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('This action will delete the font definition and the font file assets from the DragBlock\'s font library', 'dragblock')));
}
/* harmony default export */ __webpack_exports__["default"] = (ConfirmDeleteModal);

/***/ }),

/***/ "./src/applications/font-library/client/manage-fonts/font-face.js":
/*!************************************************************************!*\
  !*** ./src/applications/font-library/client/manage-fonts/font-face.js ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _demo_text_input_demo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../demo-text-input/demo */ "./src/applications/font-library/client/demo-text-input/demo.js");



const {
  __
} = wp.i18n;
function FontFace({
  face,
  deleteFont,
  shouldBeRemoved,
  isFamilyOpen
}) {
  const demoStyles = {
    fontFamily: face.fontFamily,
    fontStyle: face.fontStyle,
    // Handle cases like fontWeight is a number instead of a string or when the fontweight is a 'range', a string like "800 900".
    fontWeight: face.fontWeight ? String(face.fontWeight).split(' ')[0] : 'normal',
    ...(face.fontVariationSettings ? {
      fontVariationSettings: face.fontVariationSettings
    } : {})
  };
  if (shouldBeRemoved) {
    return null;
  }
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("tr", {
    className: "font-face"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", null, face.fontStyle), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", null, face.fontWeight), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: "demo-cell"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_demo_text_input_demo__WEBPACK_IMPORTED_MODULE_2__["default"], {
    style: demoStyles
  })), deleteFont && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.Button, {
    variant: "tertiary",
    onClick: deleteFont,
    tabIndex: isFamilyOpen ? 0 : -1
  }, __('Remove', 'dragblock'))));
}
/* harmony default export */ __webpack_exports__["default"] = (FontFace);

/***/ }),

/***/ "./src/applications/font-library/client/manage-fonts/font-family.js":
/*!**************************************************************************!*\
  !*** ./src/applications/font-library/client/manage-fonts/font-family.js ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _font_face__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./font-face */ "./src/applications/font-library/client/manage-fonts/font-face.js");
/* harmony import */ var _fonts_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../fonts-context */ "./src/applications/font-library/client/fonts-context.js");





const {
  __,
  _n
} = wp.i18n;
function FontFamily({
  fontFamily,
  deleteFont
}) {
  const {
    familiesOpen,
    handleToggleFamily
  } = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useContext)(_fonts_context__WEBPACK_IMPORTED_MODULE_3__.ManageFontsContext);
  const isOpen = familiesOpen.includes(fontFamily.name) || familiesOpen.includes(fontFamily.fontFamily);
  const toggleIsOpen = () => {
    handleToggleFamily(fontFamily.name || fontFamily.fontFamily);
  };
  if (fontFamily.shouldBeRemoved) {
    return null;
  }
  const hasFontFaces = !!fontFamily.fontFace && !!fontFamily.fontFace.length;
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("table", {
    className: "wp-list-table widefat table-view-list"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("thead", {
    onClick: toggleIsOpen
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("tr", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: "font-family-head"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("strong", null, fontFamily.name || fontFamily.fontFamily), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", null, "\xA0\xA0\xA0"), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", {
    style: {
      fontFamily: fontFamily.name || fontFamily.fontFamily,
      fontSize: '20px',
      textTransform: 'uppercase'
    }
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", {
    style: {
      textTransform: 'uppercase'
    }
  }, fontFamily.name || fontFamily.fontFamily), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", null, "\xA0"), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", {
    style: {
      textTransform: 'lowercase'
    }
  }, fontFamily.name || fontFamily.fontFamily)), hasFontFaces && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("span", {
    className: "variants-count"
  }, ' ', "( ", fontFamily.fontFace.length, ' ', _n('Variant', 'Variants', fontFamily.fontFace.length, 'dragblock'), ' ', ")")), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.Button, {
    variant: "tertiary",
    onClick: e => {
      e.stopPropagation();
      deleteFont(fontFamily.name || fontFamily.fontFamily);
    }
  }, __('Remove Font Family', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.Button, {
    onClick: toggleIsOpen
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__.Icon, {
    icon: isOpen ? 'arrow-up-alt2' : 'arrow-down-alt2'
  })))))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("tbody", {
    className: "font-family-contents"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("tr", {
    className: "container"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: ` slide ${isOpen ? 'open' : 'close'}`
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("table", {
    className: "wp-list-table widefat striped table-view-list"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("thead", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("tr", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", null, __('Style', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", null, __('Weight', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", {
    className: "preview-head"
  }, __('Preview', 'dragblock')), hasFontFaces && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("td", null))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("tbody", null, hasFontFaces && fontFamily.fontFace.map((fontFace, i) => {
    if (fontFace.shouldBeRemoved) {
      return null;
    }
    return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_font_face__WEBPACK_IMPORTED_MODULE_2__["default"], {
      face: fontFace,
      key: `fontface${i}`,
      deleteFont: () => deleteFont(fontFamily.name || fontFamily.fontFamily, fontFace.fontWeight, fontFace.fontStyle),
      isFamilyOpen: isOpen
    });
  }), !hasFontFaces && fontFamily.fontFamily && (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_font_face__WEBPACK_IMPORTED_MODULE_2__["default"], {
    face: fontFamily,
    isFamilyOpen: isOpen
  })))))));
}
/* harmony default export */ __webpack_exports__["default"] = (FontFamily);

/***/ }),

/***/ "./src/applications/font-library/client/manage-fonts/help-modal.js":
/*!*************************************************************************!*\
  !*** ./src/applications/font-library/client/manage-fonts/help-modal.js ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__);



function HelpModal({
  isOpen,
  onClose
}) {
  if (!isOpen) {
    return null;
  }
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.Modal, {
    title: (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.Icon, {
      icon: 'info'
    }), ' ', (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Info', 'dragblock')),
    onRequestClose: onClose
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('You can find the definition of embeded font families in the theme.json file of your theme.', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('If your theme.json makes reference to fonts providers other than local they may not be displayed correctly.', 'dragblock')));
}
/* harmony default export */ __webpack_exports__["default"] = (HelpModal);

/***/ }),

/***/ "./src/applications/font-library/client/manage-fonts/index.js":
/*!********************************************************************!*\
  !*** ./src/applications/font-library/client/manage-fonts/index.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _font_family__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./font-family */ "./src/applications/font-library/client/manage-fonts/font-family.js");
/* harmony import */ var _demo_text_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../demo-text-input */ "./src/applications/font-library/client/demo-text-input/index.js");
/* harmony import */ var _fonts_page_layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../fonts-page-layout */ "./src/applications/font-library/client/fonts-page-layout/index.js");
/* harmony import */ var _help_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./help-modal */ "./src/applications/font-library/client/manage-fonts/help-modal.js");
/* harmony import */ var _fonts_sidebar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../fonts-sidebar */ "./src/applications/font-library/client/fonts-sidebar/index.js");
/* harmony import */ var _page_header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./page-header */ "./src/applications/font-library/client/manage-fonts/page-header.js");
/* harmony import */ var _confirm_delete_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./confirm-delete-modal */ "./src/applications/font-library/client/manage-fonts/confirm-delete-modal.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils */ "./src/applications/font-library/client/utils.js");
/* harmony import */ var _manage_fonts_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./manage-fonts.css */ "./src/applications/font-library/client/manage-fonts/manage-fonts.css");












function ManageFonts() {
  const nonce = document.querySelector('#nonce').value;

  // The element where the list of theme fonts is rendered coming from the server as JSON
  const themeFontsJsonElement = document.querySelector('#dragblock-font-library-json');

  // The form element that will be submitted to the server
  const manageFontsFormElement = document.querySelector('#manage-fonts-form');

  // The theme font list coming from the server as JSON
  const themeFontsJsonValue = themeFontsJsonElement.innerHTML;
  const themeFontsJson = JSON.parse(themeFontsJsonValue) || [];

  // The client-side theme font list is initizaliased with the server-side theme font list
  const [newThemeFonts, setNewThemeFonts] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(themeFontsJson);

  // Object where we store the font family or font face index position in the newThemeFonts array that is about to be removed
  const [fontToDelete, setFontToDelete] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)({
    fontFamily: undefined,
    weight: undefined,
    style: undefined
  });

  // dialogs states
  const [showConfirmDialog, setShowConfirmDialog] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const [isHelpOpen, setIsHelpOpen] = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  // When client side font list changes, we update the server side font list
  (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    // Avoids running this effect on the first render
    if (fontToDelete.fontFamily !== undefined) {
      // Submit the form to the server
      manageFontsFormElement.submit();
    }
  }, [newThemeFonts]);
  const toggleIsHelpOpen = () => {
    setIsHelpOpen(!isHelpOpen);
  };
  function requestDeleteConfirmation(fontFamily, weight, style) {
    setFontToDelete({
      fontFamily,
      weight,
      style
    }, setShowConfirmDialog(true));
  }
  function confirmDelete() {
    setShowConfirmDialog(false);
    // if fontFaceIndex.weight and fontFace.styles are undefined, we are deleting a font family
    if (fontToDelete.weight !== undefined && fontToDelete.style !== undefined) {
      deleteFontFace(fontToDelete.fontFamily, fontToDelete.weight, fontToDelete.style);
    } else {
      deleteFontFamily(fontToDelete.fontFamily);
    }
  }
  function cancelDelete() {
    setFontToDelete({});
    setShowConfirmDialog(false);
  }
  function deleteFontFamily(fontFamily) {
    const updatedFonts = newThemeFonts.map(family => {
      if (fontFamily === family.fontFamily || fontFamily === family.name) {
        return {
          ...family,
          shouldBeRemoved: true
        };
      }
      return family;
    });
    setNewThemeFonts(updatedFonts);
  }
  function deleteFontFace() {
    const {
      fontFamily,
      weight,
      style
    } = fontToDelete;
    const updatedFonts = newThemeFonts.reduce((acc, family) => {
      const {
        fontFace = [],
        ...updatedFamily
      } = family;
      if (fontFamily === family.fontFamily && fontFace.filter(face => !face.shouldBeRemoved).length === 1) {
        updatedFamily.shouldBeRemoved = true;
      }
      updatedFamily.fontFace = fontFace.map(face => {
        if (weight === face.fontWeight && style === face.fontStyle && (fontFamily === family.fontFamily || fontFamily === family.name)) {
          return {
            ...face,
            shouldBeRemoved: true
          };
        }
        return face;
      });
      return [...acc, updatedFamily];
    }, []);
    setNewThemeFonts(updatedFonts);
  }

  // format the theme fonts object to be used by the FontsSidebar component
  const fontsOutline = newThemeFonts.reduce((acc, fontFamily) => {
    acc[fontFamily.fontFamily] = {
      family: fontFamily.name || fontFamily.fontFamily,
      faces: (fontFamily.fontFace || []).map(face => {
        return {
          weight: face.fontWeight,
          style: face.fontStyle,
          src: (0,_utils__WEBPACK_IMPORTED_MODULE_9__.localFileAsThemeAssetUrl)(face.src[0])
        };
      })
    };
    return acc;
  }, {});
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_help_modal__WEBPACK_IMPORTED_MODULE_5__["default"], {
    isOpen: isHelpOpen,
    onClose: toggleIsHelpOpen
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_fonts_page_layout__WEBPACK_IMPORTED_MODULE_4__["default"], null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("main", null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_page_header__WEBPACK_IMPORTED_MODULE_7__["default"], {
    toggleIsHelpOpen: toggleIsHelpOpen
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_confirm_delete_modal__WEBPACK_IMPORTED_MODULE_8__["default"], {
    isOpen: showConfirmDialog,
    onConfirm: confirmDelete,
    onCancel: cancelDelete,
    fontToDelete: fontToDelete
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_demo_text_input__WEBPACK_IMPORTED_MODULE_3__["default"], null), newThemeFonts.length === 0 ? (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('There are no font families installed in DragBlock\'s font library.', 'dragblock'))) : (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "font-families"
  }, newThemeFonts.map((fontFamily, i) => (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_font_family__WEBPACK_IMPORTED_MODULE_2__["default"], {
    fontFamily: fontFamily,
    key: `fontfamily${i}`,
    deleteFont: requestDeleteConfirmation
  }))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("form", {
    method: "POST",
    id: "manage-fonts-form"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "hidden",
    name: "dragblock-font-library-new-font-json",
    value: JSON.stringify(newThemeFonts)
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("input", {
    type: "hidden",
    name: "nonce",
    value: nonce
  }))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_fonts_sidebar__WEBPACK_IMPORTED_MODULE_6__["default"], {
    title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Font Library', 'dragblock'),
    fontsOutline: fontsOutline,
    handleDeleteFontFace: requestDeleteConfirmation,
    handleDeleteFontFamily: requestDeleteConfirmation
  })));
}
/* harmony default export */ __webpack_exports__["default"] = (ManageFonts);

/***/ }),

/***/ "./src/applications/font-library/client/manage-fonts/page-header.js":
/*!**************************************************************************!*\
  !*** ./src/applications/font-library/client/manage-fonts/page-header.js ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__);



function PageHeader({
  toggleIsHelpOpen
}) {
  const {
    adminUrl
  } = dragBlockFontLib;
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "manage-fonts-header-flex"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h1", {
    className: "wp-heading-inline"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Font Library', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("div", {
    className: "buttons"
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.Button, {
    href: `${adminUrl}admin.php?page=dragblock-add-google-fonts`,
    variant: "secondary"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Add Google Font', 'dragblock')), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.Button, {
    href: `${adminUrl}admin.php?page=dragblock-add-local-fonts`,
    variant: "secondary"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Add Local Font', 'dragblock')))), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("hr", {
    className: "wp-header-end"
  }), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("p", {
    className: "help"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('There may be some fonts currently embedded in your theme', 'dragblock'), (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.Button, {
    onClick: toggleIsHelpOpen,
    style: {
      padding: '0',
      height: '1rem'
    }
  }, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__.Icon, {
    icon: 'info'
  }))));
}
/* harmony default export */ __webpack_exports__["default"] = (PageHeader);

/***/ }),

/***/ "./src/applications/font-library/client/utils.js":
/*!*******************************************************!*\
  !*** ./src/applications/font-library/client/utils.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bytesToSize: function() { return /* binding */ bytesToSize; },
/* harmony export */   downloadFile: function() { return /* binding */ downloadFile; },
/* harmony export */   forceHttps: function() { return /* binding */ forceHttps; },
/* harmony export */   getGoogleVariantFromStyleAndWeight: function() { return /* binding */ getGoogleVariantFromStyleAndWeight; },
/* harmony export */   getStyleFromGoogleVariant: function() { return /* binding */ getStyleFromGoogleVariant; },
/* harmony export */   getWeightFromGoogleVariant: function() { return /* binding */ getWeightFromGoogleVariant; },
/* harmony export */   localFileAsThemeAssetUrl: function() { return /* binding */ localFileAsThemeAssetUrl; }
/* harmony export */ });
function getStyleFromGoogleVariant(variant) {
  return variant.includes('italic') ? 'italic' : 'normal';
}
function getWeightFromGoogleVariant(variant) {
  return variant === 'regular' || variant === 'italic' ? '400' : variant.replace('italic', '');
}
function getGoogleVariantFromStyleAndWeight(style, weight) {
  if (weight === '400') {
    if (style === 'italic') {
      return 'italic';
    }
    return 'regular';
  }
  if (style === 'normal') {
    return weight;
  }
  return weight + style;
}
function forceHttps(url) {
  return url.replace('http://', 'https://');
}
function bytesToSize(bytes) {
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  if (bytes === 0) return 'n/a';
  const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
  if (i === 0) return bytes + ' ' + sizes[i];
  return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
}
function localFileAsThemeAssetUrl(url) {
  if (!url) {
    return url;
  }
  return url.replace('file:./', dragBlockFontLib.uploadUrl + '/');
}
async function downloadFile(response) {
  const blob = await response.blob();
  const filename = response.headers.get('Content-Disposition').split('filename=')[1];

  // Check if the browser supports navigator.msSaveBlob or navigator.saveBlob
  if (navigator.msSaveBlob || navigator.saveBlob) {
    const saveBlob = navigator.msSaveBlob || navigator.saveBlob;
    saveBlob.call(navigator, blob, filename);
  } else {
    // Fall back to creating an object URL and triggering a download using an anchor element
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => {
      URL.revokeObjectURL(url);
    }, 100);
  }
}

/***/ }),

/***/ "./src/applications/font-library/client/demo-text-input/demo-text-input.css":
/*!**********************************************************************************!*\
  !*** ./src/applications/font-library/client/demo-text-input/demo-text-input.css ***!
  \**********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/applications/font-library/client/fonts-page-layout/fonts-page-layout.css":
/*!**************************************************************************************!*\
  !*** ./src/applications/font-library/client/fonts-page-layout/fonts-page-layout.css ***!
  \**************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/applications/font-library/client/fonts-sidebar/fonts-sidebar.css":
/*!******************************************************************************!*\
  !*** ./src/applications/font-library/client/fonts-sidebar/fonts-sidebar.css ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/applications/font-library/client/google-fonts/google-fonts.css":
/*!****************************************************************************!*\
  !*** ./src/applications/font-library/client/google-fonts/google-fonts.css ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/applications/font-library/client/local-fonts/local-fonts.css":
/*!**************************************************************************!*\
  !*** ./src/applications/font-library/client/local-fonts/local-fonts.css ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/applications/font-library/client/manage-fonts/manage-fonts.css":
/*!****************************************************************************!*\
  !*** ./src/applications/font-library/client/manage-fonts/manage-fonts.css ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "@wordpress/components":
/*!************************************!*\
  !*** external ["wp","components"] ***!
  \************************************/
/***/ (function(module) {

module.exports = window["wp"]["components"];

/***/ }),

/***/ "@wordpress/core-data":
/*!**********************************!*\
  !*** external ["wp","coreData"] ***!
  \**********************************/
/***/ (function(module) {

module.exports = window["wp"]["coreData"];

/***/ }),

/***/ "@wordpress/data":
/*!******************************!*\
  !*** external ["wp","data"] ***!
  \******************************/
/***/ (function(module) {

module.exports = window["wp"]["data"];

/***/ }),

/***/ "@wordpress/element":
/*!*********************************!*\
  !*** external ["wp","element"] ***!
  \*********************************/
/***/ (function(module) {

module.exports = window["wp"]["element"];

/***/ }),

/***/ "@wordpress/i18n":
/*!******************************!*\
  !*** external ["wp","i18n"] ***!
  \******************************/
/***/ (function(module) {

module.exports = window["wp"]["i18n"];

/***/ }),

/***/ "@wordpress/primitives":
/*!************************************!*\
  !*** external ["wp","primitives"] ***!
  \************************************/
/***/ (function(module) {

module.exports = window["wp"]["primitives"];

/***/ }),

/***/ "./node_modules/lib-font/lib-font.js":
/*!*******************************************!*\
  !*** ./node_modules/lib-font/lib-font.js ***!
  \*******************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Font: function() { return /* binding */ Font; }
/* harmony export */ });
/* harmony import */ var _src_utils_shim_fetch_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/utils/shim-fetch.js */ "./node_modules/lib-font/src/utils/shim-fetch.js");
/* harmony import */ var _src_eventing_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./src/eventing.js */ "./node_modules/lib-font/src/eventing.js");
/* harmony import */ var _src_opentype_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/opentype/index.js */ "./node_modules/lib-font/src/opentype/index.js");
/* harmony import */ var _src_opentype_tables_createTable_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/opentype/tables/createTable.js */ "./node_modules/lib-font/src/opentype/tables/createTable.js");
/* harmony import */ var _src_utils_fontface_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./src/utils/fontface.js */ "./node_modules/lib-font/src/utils/fontface.js");
/* harmony import */ var _src_utils_validator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./src/utils/validator.js */ "./node_modules/lib-font/src/utils/validator.js");







/**
 * Borderline trivial http response helper function
 *
 * @param {HttpResponse} response
 */
function checkFetchResponseStatus(response) {
    if (!response.ok) {
        throw new Error(`HTTP ${response.status} - ${response.statusText}`);
    }
    return response;
}

/**
 * The Font object, which the WebAPIs are still sorely missing.
 */
class Font extends _src_eventing_js__WEBPACK_IMPORTED_MODULE_1__.EventManager {
    constructor(name, options={}) {
        super();
        this.name = name;
        this.options = options;
        this.metrics = false;
    }

    get src() { return this.__src; }

    /**
     * Just like Image and Audio, we kick everything off when
     * our `src` gets assigned.
     *
     * @param {string} source url for this font ("real" or blob/base64)
     */
    set src(src) {
        this.__src = src;
        (async() => {
            if (globalThis.document && !this.options.skipStyleSheet) {
                await (0,_src_utils_fontface_js__WEBPACK_IMPORTED_MODULE_4__.setupFontFace)(this.name, src, this.options);
            }
            this.loadFont(src);
        })();
    }

    /**
     * This is a non-blocking operation.
     *
     * @param {String} url The URL for the font in question
     * @param {String} filename The filename to use when URL is a blob/base64 string
     */
    async loadFont(url, filename) {
        fetch(url)
        .then(response => checkFetchResponseStatus(response) && response.arrayBuffer())
        .then(buffer => this.fromDataBuffer(buffer, filename || url))
        .catch(err => {
            const evt = new _src_eventing_js__WEBPACK_IMPORTED_MODULE_1__.Event(`error`, err, `Failed to load font at ${filename || url}`);
            this.dispatch(evt);
            if (this.onerror) this.onerror(evt);
        });
    }

    /**
     * This is a non-blocking operation.
     *
     * @param {Buffer} buffer The binary data associated with this font.
     */
    async fromDataBuffer(buffer, filenameOrUrL) {
        this.fontData = new DataView(buffer); // Big Endian
        let type = (0,_src_utils_validator_js__WEBPACK_IMPORTED_MODULE_5__.validFontFormat)(this.fontData);
        if (!type) {
            // handled in loadFont's .catch()
            throw new Error(`${filenameOrUrL} is either an unsupported font format, or not a font at all.`);
        }
        await this.parseBasicData(type);
        const evt = new _src_eventing_js__WEBPACK_IMPORTED_MODULE_1__.Event("load", { font: this });
        this.dispatch(evt);
        if (this.onload) this.onload(evt);
    }

    /**
     * This is a non-blocking operation IF called from an async function
     */
    async parseBasicData(type) {
        return (0,_src_opentype_tables_createTable_js__WEBPACK_IMPORTED_MODULE_3__.loadTableClasses)().then(createTable => {
            if (type === `SFNT`) {
                this.opentype = new _src_opentype_index_js__WEBPACK_IMPORTED_MODULE_2__.SFNT(this, this.fontData, createTable);
            }
            if (type === `WOFF`) {
                this.opentype = new _src_opentype_index_js__WEBPACK_IMPORTED_MODULE_2__.WOFF(this, this.fontData, createTable);
            }
            if (type === `WOFF2`) {
                this.opentype = new _src_opentype_index_js__WEBPACK_IMPORTED_MODULE_2__.WOFF2(this, this.fontData, createTable);
            }
            return this.opentype;
        });
    }

    /**
     * Does this font support the specified character?
     * @param {*} char
     */
    getGlyphId(char) {
        return this.opentype.tables.cmap.getGlyphId(char);
    }

    /**
     * find the actual "letter" for a given glyphid
     * @param {*} glyphid
     */
    reverse(glyphid) {
        return this.opentype.tables.cmap.reverse(glyphid);
    }

    /**
     * Does this font support the specified character?
     * @param {*} char
     */
    supports(char) {
        return this.getGlyphId(char) !== 0
    }

    /**
     * Does this font support the specified unicode variation?
     * @param {*} variation
     */
    supportsVariation(variation) {
        return this.opentype.tables.cmap.supportsVariation(variation) !== false;
    }

    /**
     * Effectively, be https://html.spec.whatwg.org/multipage/canvas.html#textmetrics
     * @param {*} text
     * @param {*} size
     */
    measureText(text, size=16) {
        if (this.__unloaded) throw new Error("Cannot measure text: font was unloaded. Please reload before calling measureText()");
        let d = document.createElement('div');
        d.textContent = text;
        d.style.fontFamily = this.name;
        d.style.fontSize = `${size}px`;
        d.style.color = `transparent`;
        d.style.background = `transparent`;
        d.style.top = `0`;
        d.style.left = `0`;
        d.style.position = `absolute`;
        document.body.appendChild(d);
        let bbox = d.getBoundingClientRect();
        document.body.removeChild(d);
        const OS2 = this.opentype.tables["OS/2"];
        bbox.fontSize = size;
        bbox.ascender = OS2.sTypoAscender;
        bbox.descender = OS2.sTypoDescender;
        return bbox;
    }

    /**
     * unload this font from the DOM context, making it no longer available for CSS purposes
     */
    unload() {
        if (this.styleElement.parentNode) {
            this.styleElement.parentNode.removeElement(this.styleElement);
            const evt = new _src_eventing_js__WEBPACK_IMPORTED_MODULE_1__.Event("unload", { font: this });
            this.dispatch(evt);
            if (this.onunload) this.onunload(evt);
        }
        this._unloaded = true;
    }

    /**
     * load this font back into the DOM context after being unload()'d earlier.
     */
    load() {
        if (this.__unloaded) {
            delete this.__unloaded;
            document.head.appendChild(this.styleElement);
            const evt = new _src_eventing_js__WEBPACK_IMPORTED_MODULE_1__.Event("load", { font: this });
            this.dispatch(evt);
            if (this.onload) this.onload(evt);
        }
    }
}

globalThis.Font = Font;




/***/ }),

/***/ "./node_modules/lib-font/src/eventing.js":
/*!***********************************************!*\
  !*** ./node_modules/lib-font/src/eventing.js ***!
  \***********************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Event: function() { return /* binding */ Event; },
/* harmony export */   EventManager: function() { return /* binding */ EventManager; }
/* harmony export */ });
/**
 * Simple event manager so people can write the
 * same code in the browser and in Node.
 */
class Event {
  constructor(type, detail = {}, msg) {
    this.type = type;
    this.detail = detail;
    this.msg = msg;
    Object.defineProperty(this, `__mayPropagate`, {
      enumerable: false,
      writable: true,
    });
    this.__mayPropagate = true;
  }
  preventDefault() {
    /* does nothing */
  }
  stopPropagation() {
    this.__mayPropagate = false;
  }
  valueOf() {
    return this;
  }
  toString() {
    return this.msg
      ? `[${this.type} event]: ${this.msg}`
      : `[${this.type} event]`;
  }
}

/**
 * Simple event manager so people can write the
 * same code in the browser and in Node.
 */
class EventManager {
  constructor() {
    this.listeners = {};
  }
  addEventListener(type, listener, useCapture) {
    let bin = this.listeners[type] || [];
    if (useCapture) bin.unshift(listener);
    else bin.push(listener);
    this.listeners[type] = bin;
  }
  removeEventListener(type, listener) {
    let bin = this.listeners[type] || [];
    let pos = bin.findIndex((e) => e === listener);
    if (pos > -1) {
      bin.splice(pos, 1);
      this.listeners[type] = bin;
    }
  }
  dispatch(event) {
    let bin = this.listeners[event.type];
    if (bin) {
      for (let l = 0, e = bin.length; l < e; l++) {
        if (!event.__mayPropagate) break;
        bin[l](event);
      }
    }
  }
}




/***/ }),

/***/ "./node_modules/lib-font/src/lazy.js":
/*!*******************************************!*\
  !*** ./node_modules/lib-font/src/lazy.js ***!
  \*******************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ lazy; }
/* harmony export */ });
/**
 * This is a lazy loader but is not optimised for direct record selection,
 * so code will currently load "An entire array" even if it needs only
 * a single element from that array, and the array elements are fixed width.
 *
 * @param {*} object
 * @param {*} property
 * @param {*} getter
 */
function lazy(object, property, getter) {
  let val;
  Object.defineProperty(object, property, {
    get: () => {
      if (val) return val;
      val = getter();
      return val;
    },
    enumerable: true,
  });
}


/***/ }),

/***/ "./node_modules/lib-font/src/opentype/index.js":
/*!*****************************************************!*\
  !*** ./node_modules/lib-font/src/opentype/index.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SFNT: function() { return /* reexport safe */ _sfnt_js__WEBPACK_IMPORTED_MODULE_0__.SFNT; },
/* harmony export */   WOFF: function() { return /* reexport safe */ _woff_js__WEBPACK_IMPORTED_MODULE_1__.WOFF; },
/* harmony export */   WOFF2: function() { return /* reexport safe */ _woff2_js__WEBPACK_IMPORTED_MODULE_2__.WOFF2; }
/* harmony export */ });
/* harmony import */ var _sfnt_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sfnt.js */ "./node_modules/lib-font/src/opentype/sfnt.js");
/* harmony import */ var _woff_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./woff.js */ "./node_modules/lib-font/src/opentype/woff.js");
/* harmony import */ var _woff2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./woff2.js */ "./node_modules/lib-font/src/opentype/woff2.js");






/***/ }),

/***/ "./node_modules/lib-font/src/opentype/sfnt.js":
/*!****************************************************!*\
  !*** ./node_modules/lib-font/src/opentype/sfnt.js ***!
  \****************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SFNT: function() { return /* binding */ SFNT; }
/* harmony export */ });
/* harmony import */ var _tables_simple_table_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tables/simple-table.js */ "./node_modules/lib-font/src/opentype/tables/simple-table.js");
/* harmony import */ var _lazy_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lazy.js */ "./node_modules/lib-font/src/lazy.js");



/**
 * the SFNT header.
 *
 * See https://docs.microsoft.com/en-us/typography/opentype/spec/overview for more information
 */
class SFNT extends _tables_simple_table_js__WEBPACK_IMPORTED_MODULE_0__.SimpleTable {
  constructor(font, dataview, createTable) {
    const { p } = super({ offset: 0, length: 12 }, dataview, `sfnt`);

    this.version = p.uint32;
    this.numTables = p.uint16;
    this.searchRange = p.uint16;
    this.entrySelector = p.uint16;
    this.rangeShift = p.uint16;

    p.verifyLength();

    this.directory = [...new Array(this.numTables)].map(
      (_) => new TableRecord(p)
    );

    // add convenience bindings for each table, with lazy loading
    this.tables = {};
    this.directory.forEach((entry) => {
      const getter = () => {
        return createTable(
          this.tables,
          {
            tag: entry.tag,
            offset: entry.offset,
            length: entry.length,
          },
          dataview
        );
      };
      (0,_lazy_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this.tables, entry.tag.trim(), getter);
    });
  }
}

/**
 * SFNT directory Table Record struct.
 */
class TableRecord {
  constructor(p) {
    this.tag = p.tag;
    this.checksum = p.uint32;
    this.offset = p.uint32;
    this.length = p.uint32;
  }
}




/***/ }),

/***/ "./node_modules/lib-font/src/opentype/tables/createTable.js":
/*!******************************************************************!*\
  !*** ./node_modules/lib-font/src/opentype/tables/createTable.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   loadTableClasses: function() { return /* binding */ loadTableClasses; }
/* harmony export */ });
// Step 1: set up a namespace for all our table classes.
const tableClasses = {};
let tableClassesLoaded = false;

// Step 2: load all the table classes. While the imports
// all resolve asynchronously, Promise.all won't "exit"
// until every class definition has been loaded.
Promise.all([
  // opentype tables
  __webpack_require__.e(/*! import() */ "vendors-node_modules_lib-font_src_opentype_tables_simple_cmap_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/cmap.js */ "./node_modules/lib-font/src/opentype/tables/simple/cmap.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_head_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/head.js */ "./node_modules/lib-font/src/opentype/tables/simple/head.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_hhea_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/hhea.js */ "./node_modules/lib-font/src/opentype/tables/simple/hhea.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_hmtx_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/hmtx.js */ "./node_modules/lib-font/src/opentype/tables/simple/hmtx.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_maxp_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/maxp.js */ "./node_modules/lib-font/src/opentype/tables/simple/maxp.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_name_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/name.js */ "./node_modules/lib-font/src/opentype/tables/simple/name.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_OS2_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/OS2.js */ "./node_modules/lib-font/src/opentype/tables/simple/OS2.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_post_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/post.js */ "./node_modules/lib-font/src/opentype/tables/simple/post.js")),

  // opentype tables that rely on the "common layout tables" data structures
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_advanced_BASE_js").then(__webpack_require__.bind(__webpack_require__, /*! ./advanced/BASE.js */ "./node_modules/lib-font/src/opentype/tables/advanced/BASE.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_advanced_GDEF_js").then(__webpack_require__.bind(__webpack_require__, /*! ./advanced/GDEF.js */ "./node_modules/lib-font/src/opentype/tables/advanced/GDEF.js")),
  Promise.all(/*! import() */[__webpack_require__.e("vendors-node_modules_lib-font_src_opentype_tables_common-layout-table_js"), __webpack_require__.e("node_modules_lib-font_src_opentype_tables_advanced_GSUB_js")]).then(__webpack_require__.bind(__webpack_require__, /*! ./advanced/GSUB.js */ "./node_modules/lib-font/src/opentype/tables/advanced/GSUB.js")),
  Promise.all(/*! import() */[__webpack_require__.e("vendors-node_modules_lib-font_src_opentype_tables_common-layout-table_js"), __webpack_require__.e("node_modules_lib-font_src_opentype_tables_advanced_GPOS_js")]).then(__webpack_require__.bind(__webpack_require__, /*! ./advanced/GPOS.js */ "./node_modules/lib-font/src/opentype/tables/advanced/GPOS.js")),

  // SVG tables... err... table
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_SVG_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/SVG.js */ "./node_modules/lib-font/src/opentype/tables/simple/SVG.js")),

  // Variable fonts
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_variation_fvar_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/variation/fvar.js */ "./node_modules/lib-font/src/opentype/tables/simple/variation/fvar.js")),

  // TTF tables
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_ttf_cvt_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/ttf/cvt.js */ "./node_modules/lib-font/src/opentype/tables/simple/ttf/cvt.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_ttf_fpgm_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/ttf/fpgm.js */ "./node_modules/lib-font/src/opentype/tables/simple/ttf/fpgm.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_ttf_gasp_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/ttf/gasp.js */ "./node_modules/lib-font/src/opentype/tables/simple/ttf/gasp.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_ttf_glyf_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/ttf/glyf.js */ "./node_modules/lib-font/src/opentype/tables/simple/ttf/glyf.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_ttf_loca_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/ttf/loca.js */ "./node_modules/lib-font/src/opentype/tables/simple/ttf/loca.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_ttf_prep_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/ttf/prep.js */ "./node_modules/lib-font/src/opentype/tables/simple/ttf/prep.js")),

  // CFF
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_cff_CFF_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/cff/CFF.js */ "./node_modules/lib-font/src/opentype/tables/simple/cff/CFF.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_cff_CFF2_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/cff/CFF2.js */ "./node_modules/lib-font/src/opentype/tables/simple/cff/CFF2.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_cff_VORG_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/cff/VORG.js */ "./node_modules/lib-font/src/opentype/tables/simple/cff/VORG.js")),

  // bitmap
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_bitmap_EBLC_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/bitmap/EBLC.js */ "./node_modules/lib-font/src/opentype/tables/simple/bitmap/EBLC.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_bitmap_EBDT_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/bitmap/EBDT.js */ "./node_modules/lib-font/src/opentype/tables/simple/bitmap/EBDT.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_bitmap_EBSC_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/bitmap/EBSC.js */ "./node_modules/lib-font/src/opentype/tables/simple/bitmap/EBSC.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_bitmap_CBLC_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/bitmap/CBLC.js */ "./node_modules/lib-font/src/opentype/tables/simple/bitmap/CBLC.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_bitmap_CBDT_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/bitmap/CBDT.js */ "./node_modules/lib-font/src/opentype/tables/simple/bitmap/CBDT.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_bitmap_sbix_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/bitmap/sbix.js */ "./node_modules/lib-font/src/opentype/tables/simple/bitmap/sbix.js")),

  // color
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_color_COLR_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/color/COLR.js */ "./node_modules/lib-font/src/opentype/tables/simple/color/COLR.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_color_CPAL_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/color/CPAL.js */ "./node_modules/lib-font/src/opentype/tables/simple/color/CPAL.js")),

  // "other" tables
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_DSIG_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/DSIG.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/DSIG.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_hdmx_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/hdmx.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/hdmx.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_kern_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/kern.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/kern.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_LTSH_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/LTSH.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/LTSH.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_MERG_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/MERG.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/MERG.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_meta_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/meta.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/meta.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_PCLT_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/PCLT.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/PCLT.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_VDMX_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/VDMX.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/VDMX.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_vhea_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/vhea.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/vhea.js")),
  __webpack_require__.e(/*! import() */ "node_modules_lib-font_src_opentype_tables_simple_other_vmtx_js").then(__webpack_require__.bind(__webpack_require__, /*! ./simple/other/vmtx.js */ "./node_modules/lib-font/src/opentype/tables/simple/other/vmtx.js")),
])

  // Step 3: rebind all the class imports so that
  // we can fetch constructors given table names.
  .then((data) => {
    data.forEach((e) => {
      let name = Object.keys(e)[0];
      tableClasses[name] = e[name];
    });
    tableClassesLoaded = true;
  });

/**
 * Step 4: set up a table factory that can build tables given a name tag.
 * @param {*} tables the object containing actual table instances.
 * @param {*} dict an object of the form: { tag: "string", offset: <number>, [length: <number>]}
 * @param {*} dataview a DataView object over an ArrayBuffer of Uint8Array
 */
function createTable(tables, dict, dataview) {
  let name = dict.tag.replace(/[^\w\d]/g, ``);
  let Type = tableClasses[name];
  if (Type) return new Type(dict, dataview, tables);
  console.warn(
    `lib-font has no definition for ${name}. The table was skipped.`
  );
  return {};
}

function loadTableClasses() {
  let count = 0;
  function checkLoaded(resolve, reject) {
    if (!tableClassesLoaded) {
      if (count > 10) {
        return reject(new Error(`loading took too long`));
      }
      count++;
      return setTimeout(() => checkLoaded(resolve), 250);
    }
    resolve(createTable);
  }
  return new Promise((resolve, reject) => checkLoaded(resolve));
}




/***/ }),

/***/ "./node_modules/lib-font/src/opentype/tables/simple-table.js":
/*!*******************************************************************!*\
  !*** ./node_modules/lib-font/src/opentype/tables/simple-table.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SimpleTable: function() { return /* binding */ SimpleTable; }
/* harmony export */ });
/* harmony import */ var _parser_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../parser.js */ "./node_modules/lib-font/src/parser.js");


class SimpleTable extends _parser_js__WEBPACK_IMPORTED_MODULE_0__.ParsedData {
  constructor(dict, dataview, name) {
    const { parser, start } = super(new _parser_js__WEBPACK_IMPORTED_MODULE_0__.Parser(dict, dataview, name));

    // alias the parser as "p"
    const pGetter = { enumerable: false, get: () => parser };
    Object.defineProperty(this, `p`, pGetter);

    // alias the start offset as "tableStart"
    const startGetter = { enumerable: false, get: () => start };
    Object.defineProperty(this, `tableStart`, startGetter);
  }
}




/***/ }),

/***/ "./node_modules/lib-font/src/opentype/woff.js":
/*!****************************************************!*\
  !*** ./node_modules/lib-font/src/opentype/woff.js ***!
  \****************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WOFF: function() { return /* binding */ WOFF; }
/* harmony export */ });
/* harmony import */ var _tables_simple_table_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tables/simple-table.js */ "./node_modules/lib-font/src/opentype/tables/simple-table.js");
/* harmony import */ var _lazy_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lazy.js */ "./node_modules/lib-font/src/lazy.js");



const gzipDecode = globalThis.pako ? globalThis.pako.inflate : undefined;
let nativeGzipDecode = undefined;

if (!gzipDecode) {
  __webpack_require__.e(/*! import() */ "_999c").then(__webpack_require__.t.bind(__webpack_require__, /*! zlib */ "?999c", 19)).then((zlib) => {
    nativeGzipDecode = (buffer) => zlib.unzipSync(buffer);
  });
}

/**
 * The WOFF header
 *
 * See https://www.w3.org/TR/WOFF for WOFF information
 * See https://docs.microsoft.com/en-us/typography/opentype/spec/overview for font information
 */
class WOFF extends _tables_simple_table_js__WEBPACK_IMPORTED_MODULE_0__.SimpleTable {
  constructor(font, dataview, createTable) {
    const { p } = super({ offset: 0, length: 44 }, dataview, `woff`);

    this.signature = p.tag;
    this.flavor = p.uint32;
    this.length = p.uint32;
    this.numTables = p.uint16;
    p.uint16;
    this.totalSfntSize = p.uint32;
    this.majorVersion = p.uint16;
    this.minorVersion = p.uint16;
    this.metaOffset = p.uint32;
    this.metaLength = p.uint32;
    this.metaOrigLength = p.uint32;
    this.privOffset = p.uint32;
    this.privLength = p.uint32;

    p.verifyLength();

    this.directory = [...new Array(this.numTables)].map(
      (_) => new WoffTableDirectoryEntry(p)
    );
    buildWoffLazyLookups(this, dataview, createTable);
  }
}

/**
 * ...
 */
class WoffTableDirectoryEntry {
  constructor(p) {
    this.tag = p.tag;
    this.offset = p.uint32;
    this.compLength = p.uint32;
    this.origLength = p.uint32;
    this.origChecksum = p.uint32;
  }
}

/**
 * Build late-evaluating properties for each table in a
 * woff/woff2 font, so that accessing a table via the
 * woff.tables.tableName or woff2.tables.tableName
 * property kicks off a table parse on first access.
 *
 * @param {*} woff the woff or woff2 font object
 * @param {DataView} dataview passed when dealing with woff
 * @param {buffer} decoded passed when dealing with woff2
 */
function buildWoffLazyLookups(woff, dataview, createTable) {
  woff.tables = {};
  woff.directory.forEach((entry) => {
    (0,_lazy_js__WEBPACK_IMPORTED_MODULE_1__["default"])(woff.tables, entry.tag.trim(), () => {
      let offset = 0;
      let view = dataview;
      // compressed data?
      if (entry.compLength !== entry.origLength) {
        const data = dataview.buffer.slice(
          entry.offset,
          entry.offset + entry.compLength
        );

        let unpacked;
        if (gzipDecode) {
          unpacked = gzipDecode(new Uint8Array(data));
        } else if (nativeGzipDecode) {
          unpacked = nativeGzipDecode(new Uint8Array(data));
        } else {
          const msg = `no brotli decoder available to decode WOFF2 font`;
          if (font.onerror) font.onerror(msg);
          throw new Error(msg);
        }

        view = new DataView(unpacked.buffer);
      }
      // uncompressed data.
      else {
        offset = entry.offset;
      }
      return createTable(
        woff.tables,
        { tag: entry.tag, offset, length: entry.origLength },
        view
      );
    });
  });
}




/***/ }),

/***/ "./node_modules/lib-font/src/opentype/woff2.js":
/*!*****************************************************!*\
  !*** ./node_modules/lib-font/src/opentype/woff2.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WOFF2: function() { return /* binding */ WOFF2; }
/* harmony export */ });
/* harmony import */ var _tables_simple_table_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tables/simple-table.js */ "./node_modules/lib-font/src/opentype/tables/simple-table.js");
/* harmony import */ var _lazy_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lazy.js */ "./node_modules/lib-font/src/lazy.js");



const brotliDecode = globalThis.unbrotli;
let nativeBrotliDecode = undefined;

if (!brotliDecode) {
  __webpack_require__.e(/*! import() */ "_999c").then(__webpack_require__.t.bind(__webpack_require__, /*! zlib */ "?999c", 19)).then((zlib) => {
    nativeBrotliDecode = (buffer) => zlib.brotliDecompressSync(buffer);
  });
}

/**
 * The WOFF2 header
 *
 * See https://www.w3.org/TR/WOFF2 for WOFF2 information
 * See https://docs.microsoft.com/en-us/typography/opentype/spec/overview for font information
 */
class WOFF2 extends _tables_simple_table_js__WEBPACK_IMPORTED_MODULE_0__.SimpleTable {
  constructor(font, dataview, createTable) {
    const { p } = super({ offset: 0, length: 48 }, dataview, `woff2`);
    this.signature = p.tag;
    this.flavor = p.uint32;
    this.length = p.uint32;
    this.numTables = p.uint16;
    p.uint16; // why woff2 even has any reserved bytes is a complete mystery. But it does.
    this.totalSfntSize = p.uint32;
    this.totalCompressedSize = p.uint32;
    this.majorVersion = p.uint16;
    this.minorVersion = p.uint16;
    this.metaOffset = p.uint32;
    this.metaLength = p.uint32;
    this.metaOrigLength = p.uint32;
    this.privOffset = p.uint32;
    this.privLength = p.uint32;

    p.verifyLength();

    // parse the dictionary
    this.directory = [...new Array(this.numTables)].map(
      (_) => new Woff2TableDirectoryEntry(p)
    );
    let dictOffset = p.currentPosition; // = start of CompressedFontData block

    // compute table byte offsets in the decompressed data
    this.directory[0].offset = 0;
    this.directory.forEach((e, i) => {
      let next = this.directory[i + 1];
      if (next) {
        next.offset =
          e.offset +
          (e.transformLength !== undefined ? e.transformLength : e.origLength);
      }
    });

    // then decompress the original data and lazy-bind
    let decoded;
    let buffer = dataview.buffer.slice(dictOffset);

    if (brotliDecode) {
      decoded = brotliDecode(new Uint8Array(buffer));
    } else if (nativeBrotliDecode) {
      decoded = new Uint8Array(nativeBrotliDecode(buffer));
    } else {
      const msg = `no brotli decoder available to decode WOFF2 font`;
      if (font.onerror) font.onerror(msg);
      throw new Error(msg);
    }

    buildWoff2LazyLookups(this, decoded, createTable);
  }
}

/**
 * WOFF2 Table Directory Entry
 */
class Woff2TableDirectoryEntry {
  constructor(p) {
    this.flags = p.uint8;

    const tagNumber = (this.tagNumber = this.flags & 63);
    if (tagNumber === 63) {
      this.tag = p.tag;
    } else {
      this.tag = getWOFF2Tag(tagNumber);
    }

    /*
        "Bits 6 and 7 indicate the preprocessing transformation version number (0-3)
        that was applied to each table. For all tables in a font, except for 'glyf'
        and 'loca' tables, transformation version 0 indicates the null transform
        where the original table data is passed directly to the Brotli compressor
        for inclusion in the compressed data stream. For 'glyf' and 'loca' tables,
        transformation version 3 indicates the null transform"
    */
    const transformVersion = (this.transformVersion = (this.flags & 192) >> 6);
    let hasTransforms = transformVersion !== 0;
    if (this.tag === `glyf` || this.tag === `loca`) {
      hasTransforms = this.transformVersion !== 3;
    }

    this.origLength = p.uint128;
    if (hasTransforms) {
      this.transformLength = p.uint128;
    }
  }
}

/**
 * Build late-evaluating properties for each table in a
 * woff2 font, so that accessing a table via the
 * font.opentype.tables.tableName property kicks off
 * a table parse on first access.
 *
 * @param {*} woff2 the woff2 font object
 * @param {decoded} the original (decompressed) SFNT data
 * @param {createTable} the opentype table builder function
 */
function buildWoff2LazyLookups(woff2, decoded, createTable) {
  woff2.tables = {};
  woff2.directory.forEach((entry) => {
    (0,_lazy_js__WEBPACK_IMPORTED_MODULE_1__["default"])(woff2.tables, entry.tag.trim(), () => {
      const start = entry.offset;
      const end =
        start +
        (entry.transformLength ? entry.transformLength : entry.origLength);
      const data = new DataView(decoded.slice(start, end).buffer);
      try {
        return createTable(
          woff2.tables,
          { tag: entry.tag, offset: 0, length: entry.origLength },
          data
        );
      } catch (e) {
        console.error(e);
      }
    });
  });
}

/**
 * WOFF2 uses a numbered tag registry, such that only unknown tables require a 4 byte tag
 * in the WOFF directory entry struct. Everything else uses a uint8. Nice and tidy.
 * @param {*} flag
 */
function getWOFF2Tag(flag) {
  return [
    `cmap`,
    `head`,
    `hhea`,
    `hmtx`,
    `maxp`,
    `name`,
    `OS/2`,
    `post`,
    `cvt `,
    `fpgm`,
    `glyf`,
    `loca`,
    `prep`,
    `CFF `,
    `VORG`,
    `EBDT`,
    `EBLC`,
    `gasp`,
    `hdmx`,
    `kern`,
    `LTSH`,
    `PCLT`,
    `VDMX`,
    `vhea`,
    `vmtx`,
    `BASE`,
    `GDEF`,
    `GPOS`,
    `GSUB`,
    `EBSC`,
    `JSTF`,
    `MATH`,
    `CBDT`,
    `CBLC`,
    `COLR`,
    `CPAL`,
    `SVG `,
    `sbix`,
    `acnt`,
    `avar`,
    `bdat`,
    `bloc`,
    `bsln`,
    `cvar`,
    `fdsc`,
    `feat`,
    `fmtx`,
    `fvar`,
    `gvar`,
    `hsty`,
    `just`,
    `lcar`,
    `mort`,
    `morx`,
    `opbd`,
    `prop`,
    `trak`,
    `Zapf`,
    `Silf`,
    `Glat`,
    `Gloc`,
    `Feat`,
    `Sill`,
  ][flag & 63];
}




/***/ }),

/***/ "./node_modules/lib-font/src/parser.js":
/*!*********************************************!*\
  !*** ./node_modules/lib-font/src/parser.js ***!
  \*********************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ParsedData: function() { return /* binding */ ParsedData; },
/* harmony export */   Parser: function() { return /* binding */ Parser; }
/* harmony export */ });
const startDate = new Date(`1904-01-01T00:00:00+0000`).getTime();

/**
 * Convert an array of uint8 char into a proper string.
 *
 * @param {uint8[]} data
 */
function asText(data) {
  return Array.from(data)
    .map((v) => String.fromCharCode(v))
    .join(``);
}

/**
 * A data parser for table data, with auto-advancing pointer.
 */
class Parser {
  constructor(dict, dataview, name) {
    this.name = (name || dict.tag || ``).trim();
    this.length = dict.length;
    this.start = dict.offset;
    this.offset = 0;
    this.data = dataview;

    [
      `getInt8`,
      `getUint8`,
      `getInt16`,
      `getUint16`,
      `getInt32`,
      `getUint32`,
      `getBigInt64`,
      `getBigUint64`,
    ].forEach((name) => {
      let fn = name.replace(/get(Big)?/, "").toLowerCase();
      let increment = parseInt(name.replace(/[^\d]/g, "")) / 8;
      Object.defineProperty(this, fn, {
        get: () => this.getValue(name, increment),
      });
    });
  }

  get currentPosition() {
    return this.start + this.offset;
  }

  set currentPosition(position) {
    this.start = position;
    this.offset = 0;
  }

  skip(n = 0, bits = 8) {
    this.offset += (n * bits) / 8;
  }

  getValue(type, increment) {
    let pos = this.start + this.offset;
    this.offset += increment;
    try {
      return this.data[type](pos);
    } catch (e) {
      console.error(`parser`, type, increment, this);
      console.error(`parser`, this.start, this.offset);
      throw e;
    }
  }

  flags(n) {
    if (n === 8 || n === 16 || n === 32 || n === 64) {
      return this[`uint${n}`]
        .toString(2)
        .padStart(n, 0)
        .split(``)
        .map((v) => v === "1");
    }
    console.error(
      `Error parsing flags: flag types can only be 1, 2, 4, or 8 bytes long`
    );
    console.trace();
  }

  get tag() {
    const t = this.uint32;
    return asText([(t >> 24) & 255, (t >> 16) & 255, (t >> 8) & 255, t & 255]);
  }

  get fixed() {
    let major = this.int16;
    let minor = Math.round((1000 * this.uint16) / 65356);
    return major + minor / 1000;
  }

  get legacyFixed() {
    // Only used in the `maxp`, `post`, and `vhea` tables.
    let major = this.uint16;
    let minor = this.uint16.toString(16).padStart(4, 0);
    return parseFloat(`${major}.${minor}`);
  }

  get uint24() {
    // Why does DataView not have a 24 bit value getters?
    return (this.uint8 << 16) + (this.uint8 << 8) + this.uint8;
  }

  get uint128() {
    // I have no idea why the variable uint128 was chosen over a
    // fixed-width uint32, but it was, and so we need to decode it.
    let value = 0;
    for (let i = 0; i < 5; i++) {
      let byte = this.uint8;
      value = value * 128 + (byte & 127);
      if (byte < 128) break;
    }
    return value;
  }

  get longdatetime() {
    return new Date(startDate + 1000 * parseInt(this.int64.toString()));
  }

  // alias datatypes

  get fword() {
    return this.int16;
  }
  get ufword() {
    return this.uint16;
  }
  get Offset16() {
    return this.uint16;
  }
  get Offset32() {
    return this.uint32;
  }

  // "that weird datatype"
  get F2DOT14() {
    const bits = p.uint16;
    const integer = [0, 1, -2, -1][bits >> 14];
    const fraction = bits & 0x3fff;
    return integer + fraction / 16384;
  }

  verifyLength() {
    if (this.offset != this.length) {
      console.error(
        `unexpected parsed table size (${this.offset}) for "${this.name}" (expected ${this.length})`
      );
    }
  }

  /**
   * Read an entire data block.
   */
  readBytes(n = 0, position = 0, bits = 8, signed = false) {
    n = n || this.length;
    if (n === 0) return [];

    if (position) this.currentPosition = position;

    const fn = `${signed ? `` : `u`}int${bits}`,
      slice = [];
    while (n--) slice.push(this[fn]);
    return slice;
  }
}

/**
 * ... docs go here ...
 */
class ParsedData {
  constructor(parser) {
    const pGetter = { enumerable: false, get: () => parser };
    Object.defineProperty(this, `parser`, pGetter);

    const start = parser.currentPosition;
    const startGetter = { enumerable: false, get: () => start };
    Object.defineProperty(this, `start`, startGetter);
  }

  load(struct) {
    Object.keys(struct).forEach((p) => {
      let props = Object.getOwnPropertyDescriptor(struct, p);
      if (props.get) {
        this[p] = props.get.bind(this);
      } else if (props.value !== undefined) {
        this[p] = props.value;
      }
    });
    if (this.parser.length) {
      this.parser.verifyLength();
    }
  }
}




/***/ }),

/***/ "./node_modules/lib-font/src/utils/fontface.js":
/*!*****************************************************!*\
  !*** ./node_modules/lib-font/src/utils/fontface.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   setupFontFace: function() { return /* binding */ setupFontFace; }
/* harmony export */ });
/**
 * Guess the font's CSS "format" by analysing the asset path.
 */
function getFontCSSFormat(path, errorOnStyle) {
  let pos = path.lastIndexOf(`.`);
  let ext = (path.substring(pos + 1) || ``).toLowerCase();

  let format = {
    ttf: `truetype`,
    otf: `opentype`,
    woff: `woff`,
    woff2: `woff2`,
  }[ext];

  if (format) return format;

  let msg = {
    eot: `The .eot format is not supported: it died in January 12, 2016, when Microsoft retired all versions of IE that didn't already support WOFF.`,
    svg: `The .svg format is not supported: SVG fonts (not to be confused with OpenType with embedded SVG) were so bad we took the entire fonts chapter out of the SVG specification again.`,
    fon: `The .fon format is not supported: this is an ancient Windows bitmap font format.`,
    ttc: `Based on the current CSS specification, font collections are not (yet?) supported.`,
  }[ext];

  if (!msg) msg = `${path} is not a known webfont format.`;

  if (errorOnStyle) {
    // hard stop if the user wants stylesheet errors to count as true errors,
    throw new Error(msg);
  } else {
    // otherwise, only leave a warning in the output log.
    console.warn(`Could not load font: ${msg}`);
  }
}

/**
 * Create an @font-face stylesheet for browser use.
 */
async function setupFontFace(name, url, options = {}) {
  if (!globalThis.document) return;

  let format = getFontCSSFormat(url, options.errorOnStyle);
  if (!format) return;

  let style = document.createElement(`style`);
  style.className = `injected-by-Font-js`;

  let rules = [];
  if (options.styleRules) {
    rules = Object.entries(options.styleRules).map(
      ([key, value]) => `${key}: ${value};`
    );
  }

  style.textContent = `
@font-face {
    font-family: "${name}";
    ${rules.join(`\n\t`)}
    src: url("${url}") format("${format}");
}`;
  globalThis.document.head.appendChild(style);
  return style;
}




/***/ }),

/***/ "./node_modules/lib-font/src/utils/shim-fetch.js":
/*!*******************************************************!*\
  !*** ./node_modules/lib-font/src/utils/shim-fetch.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/**
 * A shim for the Fetch API. If not defined, we assume we're running
 * in Node.js and shim the fetch function using the `fs` module.
 */

let fetchFunction = globalThis.fetch;

if (!fetchFunction) {
  let backlog = [];

  fetchFunction = globalThis.fetch = (...args) => {
    return new Promise((resolve, reject) => {
      backlog.push({ args, resolve, reject });
    });
  };

  __webpack_require__.e(/*! import() */ "_51e7").then(__webpack_require__.t.bind(__webpack_require__, /*! fs */ "?51e7", 19))
    .then((fs) => {
      fetchFunction = globalThis.fetch = async function (path) {
        return new Promise((resolve, reject) => {
          fs.readFile(path, (err, data) => {
            if (err) return reject(err);
            resolve({
              ok: true,
              arrayBuffer: () => data.buffer,
            });
          });
        });
      };

      while (backlog.length) {
        let instruction = backlog.shift();
        fetchFunction(...instruction.args)
          .then((data) => instruction.resolve(data))
          .catch((err) => instruction.reject(err));
      }
    })
    .catch((err) => {
      console.error(err);
      throw new Error(
        `lib-font cannot run unless either the Fetch API or Node's filesystem module is available.`
      );
    });
}

/* harmony default export */ __webpack_exports__["default"] = ("shim activated");


/***/ }),

/***/ "./node_modules/lib-font/src/utils/validator.js":
/*!******************************************************!*\
  !*** ./node_modules/lib-font/src/utils/validator.js ***!
  \******************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   validFontFormat: function() { return /* binding */ validFontFormat; }
/* harmony export */ });
// Known font header byte sequences
const TTF = [0x00, 0x01, 0x00, 0x00];
const OTF = [0x4f, 0x54, 0x54, 0x4f]; // "OTTO"
const WOFF = [0x77, 0x4f, 0x46, 0x46]; // "wOFF"
const WOFF2 = [0x77, 0x4f, 0x46, 0x32]; // "wOF2"

/**
 * Array matching function
 */
function match(ar1, ar2) {
  if (ar1.length !== ar2.length) return;
  for (let i = 0; i < ar1.length; i++) {
    if (ar1[i] !== ar2[i]) return;
  }
  return true;
}

/**
 * verify a bytestream, based on the values we know
 * should be found at the first four bytes.
 */
function validFontFormat(dataview) {
  const LEAD_BYTES = [
    dataview.getUint8(0),
    dataview.getUint8(1),
    dataview.getUint8(2),
    dataview.getUint8(3),
  ];

  if (match(LEAD_BYTES, TTF) || match(LEAD_BYTES, OTF)) return `SFNT`;
  if (match(LEAD_BYTES, WOFF)) return `WOFF`;
  if (match(LEAD_BYTES, WOFF2)) return `WOFF2`;
}




/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	!function() {
/******/ 		var getProto = Object.getPrototypeOf ? function(obj) { return Object.getPrototypeOf(obj); } : function(obj) { return obj.__proto__; };
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach(function(key) { def[key] = function() { return value[key]; }; });
/******/ 			}
/******/ 			def['default'] = function() { return value; };
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	!function() {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = function(chunkId) {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce(function(promises, key) {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	!function() {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = function(chunkId) {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/get mini-css chunk filename */
/******/ 	!function() {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.miniCssF = function(chunkId) {
/******/ 			// return url for filenames based on template
/******/ 			return undefined;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	!function() {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "dragblock:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = function(url, done, key, chunkId) {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 		
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = function(prev, event) {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach(function(fn) { return fn(event); });
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	!function() {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src;
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) {
/******/ 					var i = scripts.length - 1;
/******/ 					while (i > -1 && !scriptUrl) scriptUrl = scripts[i--].src;
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl + "../../../";
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	!function() {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"applications/font-library/client/index": 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = function(chunkId, promises) {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise(function(resolve, reject) { installedChunkData = installedChunks[chunkId] = [resolve, reject]; });
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = function(event) {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = function(parentChunkLoadingFunction, data) {
/******/ 			var chunkIds = data[0];
/******/ 			var moreModules = data[1];
/******/ 			var runtime = data[2];
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some(function(id) { return installedChunks[id] !== 0; })) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkdragblock"] = self["webpackChunkdragblock"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
!function() {
/*!*******************************************************!*\
  !*** ./src/applications/font-library/client/index.js ***!
  \*******************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _manage_fonts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./manage-fonts */ "./src/applications/font-library/client/manage-fonts/index.js");
/* harmony import */ var _google_fonts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./google-fonts */ "./src/applications/font-library/client/google-fonts/index.js");
/* harmony import */ var _local_fonts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./local-fonts */ "./src/applications/font-library/client/local-fonts/index.js");
/* harmony import */ var _fonts_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./fonts-context */ "./src/applications/font-library/client/fonts-context.js");







function App() {
  const params = new URLSearchParams(document.location.search);
  const page = params.get('page');
  const {
    adminUrl,
    fontLibSlug
  } = dragBlockFontLib;
  let PageComponent = null;
  switch (page) {
    case fontLibSlug:
      PageComponent = _manage_fonts__WEBPACK_IMPORTED_MODULE_1__["default"];
      break;
    case 'dragblock-add-google-fonts':
      PageComponent = _google_fonts__WEBPACK_IMPORTED_MODULE_2__["default"];
      break;
    case 'dragblock-add-local-fonts':
      PageComponent = _local_fonts__WEBPACK_IMPORTED_MODULE_3__["default"];
      break;
    default:
      PageComponent = () => (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)("h1", null, "This page is not implemented yet.");
      break;
  }
  return (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(_fonts_context__WEBPACK_IMPORTED_MODULE_4__.ManageFontsProvider, null, (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(PageComponent, null));
}
window.addEventListener('load', function () {
  const domNode = document.querySelector('#dragblock-font-library-app');

  // If version is less than 18 use `render` to render the app
  // otherwise use `createRoot` to render the app
  if (_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createRoot === undefined) {
    (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.render)((0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(App, null), domNode);
  } else {
    const root = (0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createRoot)(domNode);
    root.render((0,_wordpress_element__WEBPACK_IMPORTED_MODULE_0__.createElement)(App, null));
  }

  // render( <App />, document.querySelector( '#dragblock-font-library-app' ) );
}, false);
}();
/******/ })()
;
