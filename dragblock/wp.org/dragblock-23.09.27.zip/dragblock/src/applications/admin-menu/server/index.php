<?php
/**
 * DragBlock's Applications.
 *
 * @package Admin menu
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'menu-register.php';
